# Synaptix DevOps Command Center

Synaptix is an AI-first, distributed orchestration hub designed to provide a unified "Command Center" for complex enterprise infrastructure. It follows a **Brain & Hands** architecture, where a central intelligence layer orchestrates distributed agents to provide real-time observability and remediation.

---

## 🏗️ Architecture: Brain & Hands

The ecosystem is divided into three primary layers:

1.  **The Brain (API Gateway)**: A high-performance FastAPI service that manages authentication, infrastructure metadata, and the AI Copilot logic.
2.  **The Command Center (Frontend)**: A modern React/Vite application providing a generative UI interface where the AI Copilot renders intelligence directly to the user.
3.  **The Hands (Dashboard Agents)**: A single, unified Python agent (`dashboard-agent`) that can be deployed alongside K8s clusters or Podman servers. It uses a **driver-based architecture** (`K8sDriver` / `PodmanDriver`) controlled by the `AGENT_MODE` environment variable, so one codebase serves both infrastructure types on a single port (`8005`).

---

## 📋 Prerequisites

Before setting up the environment, ensure you have the following installed:
- **Python 3.12+** (with `pip` and `venv`)
- **Node.js 24+** (with `npm` or `pnpm`)
- **Git**

---

## 🛠️ Service Breakdown & Build

### 1. API Gateway (The Brain)
- **Directory**: `dashboard-apigw`
- **Port**: `8000`
- **Setup**:
  ```bash
  cd dashboard-apigw
  python3 -m venv venv
  source venv/bin/activate
  pip install -r requirements.txt
  ```
- **Database Management**:
  The system supports both **SQLite** (default) and **PostgreSQL**.
  - **SQLite Setup**: No extra configuration needed.
  - **PostgreSQL Setup**: Update `dashboard-apigw/.env` with `DB_TYPE=postgresql` and provide `DB_USER`, `DB_PASSWORD`, `DB_HOST`, and `DB_NAME`.
  
  **Initialization & Re-creation**:
  To initialize a fresh database or wipe and recreate the schema:
  ```bash
  source venv/bin/activate
  python3 -m app.db.init_db        # Creates schema
  python3 -m app.db.seed_all_data  # Loads initial admin and demo data
  ```

### 2. Frontend (The Command Center)
- **Directory**: `dashboard-frontend`
- **Port**: `5173`
- **Setup**:
  ```bash
  cd dashboard-frontend
  npm install
  ```

### 3. Dashboard Agent (The Hands)
- **Directory**: `dashboard-agent`
- **Port**: `8005` (unified, single port)
- **Modes**: `K8S` or `PODMAN` — controlled by the `AGENT_MODE` env variable
- **Setup**:
  ```bash
  cd dashboard-agent
  python3 -m venv venv
  source venv/bin/activate
  pip install -r requirements.txt
  ```
- **Configuration** (`.env`):
  ```bash
  AGENT_MODE=PODMAN        # or K8S
  AGENT_SECRET=your-secret
  ```

---

## 🚀 Running the Platform

### Unified Start (Development)
To start all services in the background and pipe logs to files:
```bash
# Start API Gateway
cd dashboard-apigw && venv/bin/uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload > backend.log 2>&1 &

# Start Dashboard Agent (choose AGENT_MODE=K8S or PODMAN)
cd dashboard-agent && AGENT_MODE=PODMAN PYTHONPATH=. venv/bin/python3 -m app.main > agent.log 2>&1 &

# Start Frontend
cd dashboard-frontend && npm run dev -- --host 0.0.0.0 > frontend.log 2>&1 &
```

---

## 停止 / Restarting (Process Management)

Managing background processes is handled via port-based termination for reliability:

### Stop Services
```bash
# Stop all dashboard components
lsof -t -i :8000,8005,5173 | xargs kill -9 2>/dev/null
```

### Restart Gateway
```bash
lsof -t -i :8000 | xargs kill -9 2>/dev/null
cd dashboard-apigw && venv/bin/uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload > backend.log 2>&1 &
```

---

## 🔌 API Documentation & Debugging

### Interactive API Docs (Swagger)
The API Gateway provides a full Swagger UI for exploring and testing endpoints:
- **URL**: [http://localhost:8000/docs](http://localhost:8000/docs)
- **ReDoc**: [http://localhost:8000/redoc](http://localhost:8000/redoc)

### Authentication Flow
To perform manual API debugging via `curl`, you must first obtain a JWT token:
```bash
curl -X POST http://localhost:8000/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{"user_id": "admin", "password": "Admin@123"}'
```

### Log Monitoring
If you encounter issues, monitor the respective service logs:
- **Brain**: `dashboard-apigw/backend.log`
- **Dashboard Agent**: `dashboard-agent/agent.log`
- **UI**: `dashboard-frontend/frontend.log`

---

## 🎨 Branding & Typography

Synaptix features a **White-labeled Typography System** designed for high-fidelity aesthetics and organizational flexibility.

### Default Premium Fonts
Out of the box, the Command Center uses a premium typeface pairing:
- **Headings & Branding**: **Outfit** (Geometric Modern Sans)
- **Body & UI Elements**: **Inter** (High-legibility UI Sans)

### Organization Specific Fonts (e.g., SC Prosper Sans)
If your organization requires specific branding (like `sc-prosper-sans`), the platform supports a seamless override mechanism:

1.  **Preparation**: Place your organization's font files (`.woff2`) in the `dashboard-frontend/public/fonts` directory.
2.  **Activation**:
    - Open `dashboard-frontend/src/index.css`.
    - Find the **ORGANIZATION OVERRIDE SECTION** at the top of the file.
    - Uncomment the `@font-face` declarations relevant to your fonts.
    - Update the CSS variable mappings:
      ```css
      :root {
        --font-family-sans: 'Your Org Font Name';
        --font-family-display: 'Your Org Font Name';
      }
      ```
3.  **Deployment**: The Vite build process will automatically bundle and prioritize your organization's typography without requiring code changes to the components.

---

## 💡 Troubleshooting Details

> [!NOTE]
> **AsyncIO Orchestration**
> The platform uses high-performance asynchronous orchestration (`httpx` + `asyncio`). Ensure that any custom dashboard agents also support asynchronous request handling for maximum responsiveness.

> [!CAUTION]
> **Encryption Keys**
> Ensure the `ENCRYPTION_KEY` matches between the API Gateway and the database for successful decryption of sensitive infrastructure credentials.