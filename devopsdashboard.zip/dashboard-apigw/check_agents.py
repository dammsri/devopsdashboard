import sys
import os
sys.path.append(os.getcwd())

from app.db.session import SessionLocal
from app.models.dashboard_agent import DashboardAgent
# Resolve relationships
import app.models.user
import app.models.application
import app.models.infrastructure
import app.models.k8s

def check():
    db = SessionLocal()
    try:
        agents = db.query(DashboardAgent).all()
        print(f"{'AGENT ID':<25} | {'TYPE':<10} | {'STATUS':<10} | {'LAST HEARD'}")
        print("-" * 70)
        for a in agents:
            print(f"{a.agent_id:<25} | {a.type:<10} | {a.status:<10} | {a.last_heard}")
    finally:
        db.close()

if __name__ == "__main__":
    check()
