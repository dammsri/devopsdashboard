"""Rename telemetry_agents to dashboard_agents

Revision ID: eec5f8f3b140
Revises: 9dc09ced7ea6
Create Date: 2026-04-22 19:54:00.000000

"""
from typing import Sequence, Union
from alembic import op
import sqlalchemy as sa

# revision identifiers, used by Alembic.
revision: str = 'eec5f8f3b140'
down_revision: Union[str, None] = '9dc09ced7ea6'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

def upgrade() -> None:
    # Rename the table
    op.rename_table('telemetry_agents', 'dashboard_agents')
    
    # Rename columns in related tables if necessary
    # Based on my research, the application model relationship was renamed, 
    # but the foreign key column name ITAM_ID remains the same.

def downgrade() -> None:
    # Revert rename
    op.rename_table('dashboard_agents', 'telemetry_agents')
