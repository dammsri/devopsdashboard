from sqlalchemy.orm import Session
from app.db.session import SessionLocal
from app.models.dashboard_agent import DashboardAgent
from app.models.application import Application

def seed_agents():
    db: Session = SessionLocal()
    try:
        # 1. K8s Agent for Cluster cl-apac-01 (ITAM: 100201)
        k8s_agent = db.query(DashboardAgent).filter(DashboardAgent.agent_id == "k8s-collector.internal").first()
        if not k8s_agent:
            k8s_agent = DashboardAgent(
                agent_id="k8s-collector.internal",
                name="APAC Primary Cluster Agent",
                type="K8S",
                endpoint="http://localhost:8005",
                secret="agent-k8s-secret",
                itam_id=100201, # Retail Mobile App
                status="healthy",
                description="Primary agent for APAC region Kubernetes clusters."
            )
            db.add(k8s_agent)
            print("✅ Seeding K8s Agent completed.")
        
        # 2. Podman Agent for Server srv-dev-001 (ITAM: 100201)
        podman_agent = db.query(DashboardAgent).filter(DashboardAgent.agent_id == "srv-dev-001").first()
        if not podman_agent:
            podman_agent = DashboardAgent(
                agent_id="srv-dev-001",
                name="Retail-Dev Host Agent",
                type="PODMAN",
                endpoint="http://localhost:8005",
                secret="agent-pod-secret",
                itam_id=100201,
                status="healthy",
                description="Resource collector for standalone development host."
            )
            db.add(podman_agent)
            print("✅ Seeding Podman Agent completed.")

        db.commit()
    except Exception as e:
        print(f"❌ Error seeding agents: {e}")
        db.rollback()
    finally:
        db.close()

if __name__ == "__main__":
    seed_agents()
