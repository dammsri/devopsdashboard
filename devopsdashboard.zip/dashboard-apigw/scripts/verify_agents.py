import sys
import os
import requests
from sqlalchemy.orm import Session
from app.db.session import SessionLocal
from app.models.dashboard_agent import DashboardAgent

def verify_agents():
    print("🔍 Starting Dashboard Agent Connectivity Check...")
    db: Session = SessionLocal()
    try:
        agents = db.query(DashboardAgent).all()
        if not agents:
            print("⚠️ No agents registered in database.")
            return

        for agent in agents:
            print(f"--- Checking Agent: {agent.name} ({agent.agent_id}) ---")
            # Standardized port 8005 fallback
            url = agent.endpoint
            if ":" not in url.replace("http://", "").replace("https://", ""):
                url = f"{url.rstrip('/')}:8005"
            
            try:
                response = requests.get(f"{url}/health", timeout=5)
                if response.status_code == 200:
                    print(f"✅ Reachable. Health: {response.json()}")
                    agent.status = "healthy"
                else:
                    print(f"❌ Unreachable. Status: {response.status_code}")
                    agent.status = "down"
            except Exception as e:
                print(f"❌ Connection Failed: {str(e)}")
                agent.status = "down"
        
        db.commit()
        print("--- Check Complete ---")
    finally:
        db.close()

if __name__ == "__main__":
    verify_agents()
