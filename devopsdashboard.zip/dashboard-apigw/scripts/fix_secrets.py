import sys
import os
from sqlalchemy.orm import Session
from app.db.session import SessionLocal
from app.models.dashboard_agent import DashboardAgent

def fix_secrets():
    """Reset all agent secrets to the default dev key for debugging."""
    db: Session = SessionLocal()
    try:
        print("🔧 Updating agent secrets to standardized dev key...")
        db.query(DashboardAgent).update({DashboardAgent.secret: "super-secret-telemetry-key"})
        
        # Verify specific ones
        k8s_agent = db.query(DashboardAgent).filter(DashboardAgent.type == "K8S").first()
        if k8s_agent:
            print(f"✅ Found K8S Agent: {k8s_agent.agent_id}")
            
        podman_agent = db.query(DashboardAgent).filter(DashboardAgent.type == "PODMAN").first()
        if podman_agent:
            print(f"✅ Found PODMAN Agent: {podman_agent.agent_id}")
            
        db.commit()
    except Exception as e:
        print(f"❌ Error: {e}")
        db.rollback()
    finally:
        db.close()

if __name__ == "__main__":
    fix_secrets()
