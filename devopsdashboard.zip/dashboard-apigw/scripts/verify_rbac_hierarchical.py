
from app.core.dependencies import require_permission
from app.models.user import User, Role, Functionality
from app.db.session import SessionLocal

db = SessionLocal()
print("Starting verification of Hierarchical RBAC...")

# 1. Fetch Admin User
user = db.query(User).filter(User.user_id == 'admin').first()
if not user:
    print("❌ Admin user not found")
    exit(1)

# 2. Check Permissions
perms = set()
for r in user.roles:
    for f in r.functionalities:
        perms.add(f.name)

print(f"User has {len(perms)} total permissions.")
# Ensure 'infra.app.manage' is in perms
if 'infra.app.manage' in perms:
    print("✅ Found 'infra.app.manage' in user permissions")
else:
    print("❌ 'infra.app.manage' NOT FOUND - DB Seeding might be incomplete")

# 3. Test require_permission wildcard
# Note: require_permission returns a function (dependency) that takes current_user
checker = require_permission('infra.app.view')
try:
    result = checker(user)
    print("✅ SUCCESS: 'infra.app.view' check passed via 'infra.app.manage' wildcard")
except Exception as e:
    print(f"❌ FAILED: {e}")

# 4. Test AI Operational Permission
checker_ai = require_permission('ai.remediate')
try:
    result = checker_ai(user)
    print("✅ SUCCESS: 'ai.remediate' check passed for Admin")
except Exception as e:
    print(f"❌ FAILED AI Check: {e}")

db.close()
