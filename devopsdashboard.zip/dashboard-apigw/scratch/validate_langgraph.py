
import os
from langchain_ollama import ChatOllama
from langchain_core.tools import tool
from langgraph.prebuilt import create_react_agent
from langchain_core.messages import HumanMessage

@tool
def get_status():
    """Check system status."""
    return "All systems operational."

try:
    model = ChatOllama(model="llama3.1:8b", temperature=0)
    agent = create_react_agent(model, tools=[get_status])
    print("SUCCESS: create_react_agent is available and initialized.")
except ImportError as e:
    print(f"IMPORT ERROR: {e}")
except Exception as e:
    print(f"OTHER ERROR: {e}")
