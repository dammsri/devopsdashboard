
import os
import json
from langchain_ollama import ChatOllama
from langchain_core.tools import tool
from langchain_core.messages import HumanMessage

@tool
def get_weather(city: str):
    """Get the weather for a city."""
    return f"The weather in {city} is sunny."

model = ChatOllama(model="llama3.1:8b", temperature=0)
model_with_tools = model.bind_tools([get_weather])

res = model_with_tools.invoke([HumanMessage(content="What is the weather in London?")])
print(f"Tool Calls: {res.tool_calls}")
print(f"Content: {res.content}")
