
import inspect
from langchain.agents import create_agent

print(f"Signature: {inspect.signature(create_agent)}")
