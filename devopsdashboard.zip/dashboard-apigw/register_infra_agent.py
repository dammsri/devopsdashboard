import sys
import os

# Add app directory to path
sys.path.append(os.getcwd())

from app.db.session import SessionLocal
from app.models.dashboard_agent import DashboardAgent
from app.models.infrastructure import Server
from app.core.encryption import encrypt_password

# Import ALL models to avoid SQLAlchemy relationship issues
import app.models.user
import app.models.application
import app.models.infrastructure
import app.models.k8s
import app.models.ai
import app.models.audit

def register_infra_agent():
    db = SessionLocal()
    try:
        # 0. Ensure Application exists for ITAM 9999
        itam_id = 9999
        from app.models.application import Application
        app = db.query(Application).filter(Application.itam_id == itam_id).first()
        if not app:
            app = Application(
                itam_id=itam_id,
                name="Infra Test App",
                description="Application for testing generic infra agents"
            )
            db.add(app)
            db.flush()
            print(f"✅ Created mock application for ITAM {itam_id}")

        # 1. Ensure we have a dummy server for local dev
        itam_id = 9999
        ip_address = "127.0.0.1"
        username = "admin"
        
        server = db.query(Server).filter(
            Server.itam_id == itam_id,
            Server.ip_address == ip_address,
            Server.username == username
        ).first()
        
        if not server:
            server = Server(
                itam_id=itam_id,
                ip_address=ip_address,
                username=username,
                password=encrypt_password("dummy"), # Required field
                hostname="LOCAL-DEV-SERVER",
                os="MacOS/Linux",
                status="Online"
            )
            db.add(server)
            db.flush()
            print(f"✅ Created mock server for ITAM {itam_id}")

        # 2. Register the INFRA Agent
        agent_id = "agent-local-infra"
        agent = db.query(DashboardAgent).filter(DashboardAgent.agent_id == agent_id).first()
        
        raw_secret = "super-secret-telemetry-key"
        encrypted_secret = encrypt_password(raw_secret)
        
        if agent:
            agent.name = "Local Infra Agent"
            agent.type = "INFRA"
            agent.endpoint = "http://localhost:8005"
            agent.secret = encrypted_secret
            agent.itam_id = itam_id
            print(f"🔄 Updated existing agent: {agent_id}")
        else:
            agent = DashboardAgent(
                agent_id=agent_id,
                name="Local Infra Agent",
                endpoint="http://localhost:8005",
                type="INFRA",
                secret=encrypted_secret,
                itam_id=itam_id,
                status="healthy"
            )
            db.add(agent)
            print(f"✅ Registered new INFRA agent: {agent_id}")
        
        db.commit()
        print("\n🚀 Registration Successful!")
        print(f"Agent ID: {agent_id}")
        print(f"ITAM ID: {itam_id}")
        print(f"Secret: {raw_secret} (Stored Encrypted)")
        
    except Exception as e:
        db.rollback()
        print(f"❌ Error: {e}")
    finally:
        db.close()

if __name__ == "__main__":
    register_infra_agent()
