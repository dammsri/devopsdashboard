import os
import json
import logging
from typing import List, Dict, Any, Optional
from datetime import datetime
from fpdf import FPDF
import markdown

from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from langchain_google_genai import ChatGoogleGenerativeAI, GoogleGenerativeAIEmbeddings
from langchain_ollama import ChatOllama, OllamaEmbeddings
from langchain_chroma import Chroma
from langchain_community.document_loaders import WebBaseLoader, PyPDFLoader, TextLoader
from langchain_core.documents import Document
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_core.tools import tool
from langchain.agents import create_agent
from langchain_core.messages import HumanMessage, AIMessage, SystemMessage
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from sqlalchemy.orm import joinedload

from app.core.config import settings
from app.ai.prompt_manager import prompt_manager
from app.models.ai import AIAuditLog
from app.db.session import SessionLocal
from app.models.application import Application
from app.models.infrastructure import Environment, Server, Service
from app.models.k8s import K8sCluster, K8sEnvironment, K8sService, K8sNamespace
from app.services.agent_service import agent_service

logger = logging.getLogger(__name__)

class SensitiveDataFilter:
    """Utility to redact sensitive information from data sent to AI."""
    
    @staticmethod
    def redact(data: Any) -> Any:
        if isinstance(data, dict):
            return {
                k: "[REDACTED]" if any(s.lower() in k.lower() for s in settings.AI_SENSITIVE_FIELDS) 
                else SensitiveDataFilter.redact(v)
                for k, v in data.items()
            }
        elif isinstance(data, list):
            return [SensitiveDataFilter.redact(item) for item in data]
        return data

class AIService:
    def __init__(self):
        self.provider = settings.AI_PROVIDER.lower()
        self.enabled = False
        
        if self.provider == "openai":
            self.api_key = settings.OPENAI_API_KEY
            if not self.api_key:
                logger.warning("OPENAI_API_KEY not set. OpenAI features will be disabled.")
                return
            self.enabled = True
            self.chat_model = ChatOpenAI(
                model=settings.OPENAI_MODEL,
                openai_api_key=self.api_key,
                streaming=True
            )
            self.insights_model = ChatOpenAI(
                model=settings.OPENAI_INSIGHTS_MODEL,
                openai_api_key=self.api_key
            )
            self.embeddings = OpenAIEmbeddings(openai_api_key=self.api_key)
            
        elif self.provider == "gemini":
            self.api_key = settings.GEMINI_API_KEY
            if not self.api_key:
                logger.warning("GEMINI_API_KEY not set. Gemini features will be disabled.")
                return
            self.enabled = True
            self.chat_model = ChatGoogleGenerativeAI(
                model=settings.GEMINI_CHAT_MODEL,
                google_api_key=self.api_key,
                streaming=True
            )
            self.insights_model = ChatGoogleGenerativeAI(
                model=settings.GEMINI_INSIGHTS_MODEL,
                google_api_key=self.api_key
            )
            self.embeddings = GoogleGenerativeAIEmbeddings(
                model=settings.GEMINI_EMBEDDING_MODEL,
                google_api_key=self.api_key
            )
        elif self.provider == "ollama":
            self.enabled = True
            # Llama 3.1 8B works best with a tiny bit of temperature for reasoning
            # but needs to be low for tool calling precision
            self.chat_model = ChatOllama(
                model="llama3.1:8b",
                base_url=settings.OLLAMA_BASE_URL,
                temperature=0.1
            )
            self.insights_model = ChatOllama(
                base_url=settings.OLLAMA_BASE_URL,
                model=settings.OLLAMA_INSIGHTS_MODEL,
                temperature=0,
            )
            self.embeddings = OllamaEmbeddings(
                base_url=settings.OLLAMA_BASE_URL,
                model=settings.OLLAMA_EMBEDDING_MODEL,
            )
        else:
            logger.error(f"Unsupported AI provider: {self.provider}")
            return

        self.vector_store = None
        self._initialize_rag()
        
        # ── Multi-Agent Initialization ──────────────────────────────────────────
        self._all_tools = self._setup_tools()
        self._specialists = {}
        self._initialize_specialists()

    def _initialize_specialists(self):
        """Creates specialized agent instances with specific instructions and sub-sets of tools."""
        # 1. K8s Engineer
        k8s_tools = [t for t in self._all_tools if any(word in t.name for word in ["k8s", "cluster"])]
        self._specialists["k8s"] = create_agent(
            model=self.chat_model,
            tools=k8s_tools,
            system_prompt=prompt_manager.get_system_prompt(persona="k8s")
        )

        # 2. Infra Ops
        infra_tools = [t for t in self._all_tools if any(word in t.name for word in ["podman", "telemetry", "server", "diagnostic", "host"])]
        self._specialists["infra"] = create_agent(
            model=self.chat_model,
            tools=infra_tools,
            system_prompt=prompt_manager.get_system_prompt(persona="infra")
        )

        # 3. Operational Auditor
        auditor_tools = [t for t in self._all_tools if any(word in t.name for word in ["application", "report"])]
        self._specialists["auditor"] = create_agent(
            model=self.chat_model,
            tools=auditor_tools,
            system_prompt=prompt_manager.get_system_prompt(persona="auditor")
        )

        # 4. Standard Agent (Default/Generalist)
        discovery_tools = [t for t in self._all_tools if any(word in t.name for word in ["application", "agent", "status"])]
        self._specialists["general"] = create_agent(
            model=self.chat_model,
            tools=discovery_tools,
            system_prompt=prompt_manager.get_system_prompt()
        )

    async def _route_query(self, message: str) -> str:
        """Uses the AI to decide which specialist should handle the query."""
        router_prompt = f"""Identify the domain of the user query. Return only one word: 'k8s', 'infra', 'auditor', or 'general'.
        - 'k8s': for pods, namespaces, clusters, deployments.
        - 'infra': for physical servers, linux, podman, CPU/Memory.
        - 'auditor': for listing apps, health reports, summaries.
        - 'general': for greetings or unidentified queries.
        
        Query: {message}"""
        
        try:
            response = await self.insights_model.ainvoke(router_prompt)
            persona = response.content.strip().lower()
            return persona if persona in ["k8s", "infra", "auditor"] else "general"
        except Exception as e:
            logger.error(f"Routing failed, falling back to general: {e}")
            return "general"

    def _setup_tools(self):
        """Standard static tools that do not require dynamic user context."""
        return []

    def _initialize_rag(self):
        """Initialize or load the persistent Chroma vector store."""
        try:
            persist_directory = settings.CHROMA_DB_PATH
            if not os.path.exists(persist_directory):
                os.makedirs(persist_directory, exist_ok=True)

            self.vector_store = Chroma(
                persist_directory=persist_directory,
                embedding_function=self.embeddings
            )
            
            # Initial seed if empty
            if len(self.vector_store.get()["ids"]) == 0:
                logger.info("Vector store is empty. Seeding from README.md...")
                readme_path = os.path.join(os.getcwd(), "..", "README.md")
                if os.path.exists(readme_path):
                    with open(readme_path, "r") as f:
                        doc = Document(page_content=f.read(), metadata={"source": "README.md"})
                        text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=100)
                        splits = text_splitter.split_documents([doc])
                        self.vector_store.add_documents(splits)
            
            logger.info("Chroma vector store initialized.")
        except Exception as e:
            logger.error(f"Failed to initialize RAG: {e}")

    async def ingest_url(self, url: str):
        """Scrapes a URL and adds its content to the vector store."""
        try:
            loader = WebBaseLoader(url)
            docs = loader.load()
            text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=100)
            splits = text_splitter.split_documents(docs)
            self.vector_store.add_documents(splits)
            logger.info(f"Successfully ingested URL: {url}")
            return {"status": "success", "chunks": len(splits)}
        except Exception as e:
            logger.error(f"URL Ingestion failed for {url}: {e}")
            raise e

    async def ingest_file(self, file_path: str):
        """Loads a file (PDF or Text) and adds its content to the vector store."""
        try:
            if file_path.endswith('.pdf'):
                loader = PyPDFLoader(file_path)
            else:
                loader = TextLoader(file_path)
            
            docs = loader.load()
            text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=100)
            splits = text_splitter.split_documents(docs)
            self.vector_store.add_documents(splits)
            logger.info(f"Successfully ingested file: {file_path}")
            return {"status": "success", "chunks": len(splits)}
        except Exception as e:
            logger.error(f"File Ingestion failed for {file_path}: {e}")
            raise e

    async def chat(self, message: str, history: List[Dict[str, str]] = None, user_permissions: List[str] = None) -> Any:
        try:
            if not self.enabled: return "AI service is currently disabled."
            filtered_message = SensitiveDataFilter.redact(message)
            
            # 0. Define ALL tools dynamically inside the chat scope so they can access 'user_permissions' natively.
            @tool
            def get_all_applications() -> str:
                """Retrieves a list of all applications managed in the system. Requires 'sys.apps.view'."""
                if not any(p in user_permissions for p in ["sys.apps.view", "sys.security.manage"]):
                    return "PERMISSION DENIED: You do not have 'sys.apps.view' permission."
                db = SessionLocal()
                try:
                    apps = db.query(Application).all()
                    return json.dumps([{"itam_id": a.itam_id, "name": a.name, "criticality": a.criticality} for a in apps])
                finally:
                    db.close()

            @tool
            def get_application_summary(itam_id: int) -> str:
                """Fetches a detailed health and dependency summary for a specific application by ITAM ID. Requires 'sys.apps.view'."""
                if not any(p in user_permissions for p in ["sys.apps.view", "sys.security.manage"]):
                    return "PERMISSION DENIED: You do not have 'sys.apps.view' permission."
                db = SessionLocal()
                try:
                    app = db.query(Application).filter(Application.itam_id == itam_id).first()
                    if not app: return f"Application {itam_id} not found."
                    return json.dumps({
                        "name": app.name,
                        "itam_id": app.itam_id,
                        "k8s_clusters": [c.name for c in app.k8s_clusters],
                        "podman_servers": [s.hostname for s in app.servers]
                    })
                finally:
                    db.close()

            @tool
            def get_infrastructure_status() -> str:
                """Global view of all K8s clusters and Podman servers status. Requires 'sys.infra.view'."""
                if not any(p in user_permissions for p in ["sys.infra.view", "sys.security.manage"]):
                    return "PERMISSION DENIED: You do not have 'sys.infra.view' permission."
                db = SessionLocal()
                try:
                    clusters = db.query(K8sCluster).all()
                    servers = db.query(Server).all()
                    return json.dumps({
                        "k8s_clusters": [{"id": c.cluster_id, "name": c.name, "status": "Active"} for c in clusters],
                        "podman_servers": [{"id": s.id, "hostname": s.hostname, "status": s.status} for s in servers]
                    })
                finally:
                    db.close()

            @tool
            def list_dashboard_agents() -> str:
                """Lists all registered Dashboard Agents and their current status. Useful for discovering target agent_ids. Requires 'sys.agents.view'."""
                if not any(p in user_permissions for p in ["sys.agents.view", "sys.security.manage"]):
                    return "PERMISSION DENIED: You do not have 'sys.agents.view' permission."
                db = SessionLocal()
                try:
                    from app.models.dashboard_agent import DashboardAgent
                    agents = db.query(DashboardAgent).all()
                    return json.dumps([{"agent_id": a.agent_id, "name": a.name, "type": a.type, "status": a.status} for a in agents])
                finally:
                    db.close()

            @tool
            def suggest_action(action_type: str, target: str, rationale: str, payload: Dict[str, Any]) -> str:
                """Generates a structured JSON suggestion for a destructive or administrative action. Requires 'ai.remediate'."""
                if not any(p in user_permissions for p in ["ai.remediate", "sys.security.manage"]):
                    return "PERMISSION DENIED: You do not have 'ai.remediate' permission."
                return json.dumps({"type": "SUGGESTED_ACTION", "action": action_type, "target": target, "rationale": rationale, "payload": payload})

            @tool
            async def get_k8s_diagnostics(k8s_env_id: str, namespace: str, service_id: str) -> str:
                """Expert tool to inspect a K8s service's logs and resource definitions by ID. Requires 'ai.diagnose'."""
                if not any(p in user_permissions for p in ["ai.diagnose", "sys.security.manage"]):
                    return "PERMISSION DENIED: You do not have 'ai.diagnose' permission."
                db = SessionLocal()
                try:
                    from app.models.dashboard_agent import DashboardAgent
                    env = db.query(K8sEnvironment).filter(K8sEnvironment.k8s_env_id == k8s_env_id).first()
                    if not env: return f"No K8s environment found for id: {k8s_env_id}"
                    agent = db.query(DashboardAgent).filter(DashboardAgent.itam_id == env.itam_id, DashboardAgent.type == "K8S").first()
                    if not agent: return f"No K8S Dashboard Agent registered for ITAM ID: {env.itam_id}"
                    diag_logs = await agent_service.send_k8s_instruction(k8s_env_id, namespace, service_id, "get_logs", agent_id=agent.agent_id)
                    diag_defs = await agent_service.send_k8s_instruction(k8s_env_id, namespace, service_id, "get_resource_definitions", agent_id=agent.agent_id)
                    return json.dumps({"service_id": service_id, "definitions": diag_defs.get('data'), "logs": diag_logs.get('data')})
                finally:
                    db.close()

            @tool
            async def get_podman_diagnostics(itam_id: int, service_name: str) -> str:
                """Expert tool to inspect a Podman container's logs and config by ITAM application ID and service name. Requires 'ai.diagnose'."""
                if not any(p in user_permissions for p in ["ai.diagnose", "sys.security.manage"]):
                    return "PERMISSION DENIED: You do not have 'ai.diagnose' permission."
                db = SessionLocal()
                try:
                    from app.models.dashboard_agent import DashboardAgent
                    agent = db.query(DashboardAgent).filter(DashboardAgent.itam_id == itam_id, DashboardAgent.type == "PODMAN").first()
                    if not agent: return f"No PODMAN Dashboard Agent registered for ITAM ID: {itam_id}"
                    diag = await agent_service.send_podman_instruction(service_name, "get_logs", agent_id=agent.agent_id)
                    config = await agent_service.send_podman_instruction(service_name, "get_configuration", agent_id=agent.agent_id)
                    return json.dumps({"service_name": service_name, "itam_id": itam_id, "config": config.get('data'), "logs": diag.get('data')})
                finally:
                    db.close()

            @tool
            async def execute_secure_diagnostic(agent_id: str, lookup_query: str) -> str:
                """Authorized tool to perform a secure diagnostic lookup (e.g. 'top processes', 'disk usage') on a target host via its Dashboard Agent."""
                if not any(p in user_permissions for p in ["ai.remediate", "sys.security.manage"]):
                    return "PERMISSION DENIED: You do not have 'ai.remediate' permission."
                
                result = await agent_service.send_system_instruction(
                    "execute_command", 
                    params={"command": lookup_query}, 
                    agent_id=agent_id
                )
                return json.dumps({"agent_id": agent_id, "query": lookup_query, "result": result})

            @tool
            async def fetch_host_telemetry(agent_id: str) -> str:
                """Authorized tool to fetch secure host telemetry (CPU, Memory, Process List) from a Dashboard Agent."""
                if not any(p in user_permissions for p in ["ai.diagnose", "sys.security.manage"]):
                    return "PERMISSION DENIED: You do not have 'ai.diagnose' permission."
                
                metrics = await agent_service.send_system_instruction("get_metrics", agent_id=agent_id)
                procs = await agent_service.send_system_instruction("get_process_list", agent_id=agent_id)
                return json.dumps({
                    "agent_id": agent_id,
                    "metrics": metrics,
                    "processes": procs
                })

            @tool
            async def manage_system_service(agent_id: str, service_name: str, action: str) -> str:
                """Manages a system service (start/stop/restart/status) on a remote host. Requires 'ai.remediate'."""
                if not any(p in user_permissions for p in ["ai.remediate", "sys.security.manage"]):
                    return "PERMISSION DENIED: You do not have 'ai.remediate' permission."
                result = await agent_service.send_system_instruction(
                    "manage_service", 
                    params={"service": service_name, "operation": action}, 
                    agent_id=agent_id
                )
                return json.dumps({"agent_id": agent_id, "service": service_name, "action": action, "result": result})

            @tool
            async def read_host_config_or_log(agent_id: str, file_path: str) -> str:
                """Reads a specific configuration file or log file from a host. Requires 'ai.diagnose'."""
                if not any(p in user_permissions for p in ["ai.diagnose", "sys.security.manage"]):
                    return "PERMISSION DENIED: You do not have 'ai.diagnose' permission."
                result = await agent_service.send_system_instruction(
                    "read_file", 
                    params={"path": file_path}, 
                    agent_id=agent_id
                )
                return json.dumps({"agent_id": agent_id, "file_path": file_path, "result": result})

            @tool
            async def get_host_network_stats(agent_id: str) -> str:
                """Retrieves active network connections and listening ports from the host. Requires 'ai.diagnose'."""
                if not any(p in user_permissions for p in ["ai.diagnose", "sys.security.manage"]):
                    return "PERMISSION DENIED: You do not have 'ai.diagnose' permission."
                result = await agent_service.send_system_instruction("get_network_info", agent_id=agent_id)
                return json.dumps({"agent_id": agent_id, "network_stats": result})

            @tool
            def export_report_to_pdf(report_content: str, filename: str) -> str:
                """Converts a markdown report into a downloadable PDF file. Returns JSON status. Requires 'ai.report'."""
                if not any(p in user_permissions for p in ["ai.report", "sys.security.manage"]):
                    return "PERMISSION DENIED: You do not have 'ai.report' permission."
                try:
                    export_dir = os.path.join(os.getcwd(), "exports")
                    os.makedirs(export_dir, exist_ok=True)
                    safe_name = "".join([c for c in filename if c.isalnum() or c in (' ', '.', '-', '_')]).rstrip()
                    if not safe_name.endswith(".pdf"): safe_name += ".pdf"
                    dest_path = os.path.join(export_dir, safe_name)
                    pdf = FPDF()
                    pdf.add_page()
                    pdf.set_font("helvetica", "B", 16)
                    pdf.cell(0, 10, "DevOps Command Center Report", ln=True, align="C")
                    pdf.ln(10)
                    pdf.set_font("helvetica", "", 12)
                    for line in report_content.split('\n'):
                        pdf.multi_cell(0, 10, line)
                    pdf.output(dest_path)
                    return json.dumps({"status": "success", "filename": safe_name, "path": dest_path})
                except Exception as e:
                    return json.dumps({"status": "error", "message": f"PDF generation failed: {str(e)}"})

            @tool
            def generate_operational_report(itam_id: Optional[int] = None) -> str:
                """Generates a high-fidelity summary report of the specified application's health or global estate. Requires 'ai.report'."""
                if not any(p in user_permissions for p in ["ai.report", "sys.security.manage"]):
                    return "PERMISSION DENIED: You do not have 'ai.report' permission."
                db = SessionLocal()
                try:
                    app_count = db.query(Application).count()
                    server_count = db.query(Server).count()
                    
                    # Fetch REAL unhealthy services
                    unhealthy_svcs = db.query(K8sService).filter(K8sService.health_status != 'healthy').all()
                    unhealthy_servers = db.query(Server).filter(Server.status != 'active').all()
                    
                    critical_issues = []
                    for svc in unhealthy_svcs:
                        critical_issues.append({"component": "K8s Service", "id": svc.service_name, "status": svc.health_status})
                    for srv in unhealthy_servers:
                        critical_issues.append({"component": "Infrastructure", "id": srv.hostname, "status": srv.status})

                    data = {
                        "report_date": datetime.now().strftime('%Y-%m-%d'),
                        "application_count": app_count,
                        "server_count": server_count,
                        "unhealthy_count": len(unhealthy_svcs) + len(unhealthy_servers),
                        "critical_issues": critical_issues[:10] # Top 10 real issues
                    }
                    return json.dumps(data)
                finally:
                    db.close()

            @tool
            async def execute_operational_action(target_type: str, target_id: str, action: str, params: Optional[Dict[str, Any]] = None) -> str:
                """Expert tool to EXECUTE a remediation action on a target system. Requires 'ai.remediate'."""
                if not any(p in user_permissions for p in ["ai.remediate", "sys.security.manage"]):
                    return "PERMISSION DENIED: You do not have 'ai.remediate' permission."
                db = SessionLocal()
                try:
                    if target_type.upper() == "K8S":
                        k8s_env_id = params.get("k8s_env_id") if params else None
                        namespace = params.get("namespace") if params else "default"
                        env = db.query(K8sEnvironment).filter(K8sEnvironment.k8s_env_id == k8s_env_id).first()
                        cluster = db.query(K8sCluster).filter(K8sCluster.itam_id == env.itam_id, K8sCluster.cluster_id == env.cluster_id).first() if env else None
                        endpoint = cluster.agent_endpoint if cluster else settings.AGENT_K8S_URL
                        result = await agent_service.send_k8s_instruction(k8s_env_id, namespace, target_id, action, params, endpoint=endpoint)
                        return json.dumps({"target_type": "K8S", "result": result})
                    elif target_type.upper() == "PODMAN":
                        result = await agent_service.send_podman_instruction(params.get("service_name"), action, params, agent_id=target_id)
                        return json.dumps({"target_type": "PODMAN", "result": result})
                    return json.dumps({"error": f"Unknown target_type {target_type}"})
                finally:
                    db.close()

            all_dynamic_tools = [
                get_all_applications, get_application_summary, get_infrastructure_status, 
                list_dashboard_agents, suggest_action, get_k8s_diagnostics, get_podman_diagnostics,
                execute_secure_diagnostic, fetch_host_telemetry, manage_system_service,
                read_host_config_or_log, get_host_network_stats, export_report_to_pdf,
                generate_operational_report, execute_operational_action
            ]

            # 1. Routing: Decide which specialist to engage
            persona = await self._route_query(filtered_message)
            logger.info(f"Routing query to specialist: {persona.upper()}")

            # 2. Permission-Aware Tool Filtering
            # We filter the total toolset based on what the user is allowed to do.
            def is_authorized(tool_name: str) -> bool:
                p = user_permissions or []
                if any(word in tool_name for word in ["telemetry", "network_stats", "k8s_diagnostics", "podman_diagnostics"]):
                    return "ai.diagnose" in p or "sys.security.manage" in p
                if any(word in tool_name for word in ["secure_diagnostic", "manage_system_service", "operational_action"]):
                    return "ai.remediate" in p or "sys.security.manage" in p
                if any(word in tool_name for word in ["report", "pdf"]):
                    return "ai.report" in p or "sys.security.manage" in p
                return True # Discovery tools are always available

            # Get tools for this specialist and filter them
            specialist_tools = []
            if persona == "k8s":
                specialist_tools = [t for t in self._all_tools if any(word in t.name for word in ["k8s", "cluster"])]
            elif persona == "infra":
                specialist_tools = [t for t in self._all_tools if any(word in t.name for word in ["podman", "telemetry", "server", "diagnostic", "host"])]
            elif persona == "auditor":
                specialist_tools = [t for t in self._all_tools if any(word in t.name for word in ["report", "pdf", "application", "summary"])]
            else: # general
                specialist_tools = self._all_tools

            authorized_tools = [t for t in specialist_tools if is_authorized(t.name)]

            # Create a fresh agent instance for this specific query with ONLY authorized tools
            agent = create_agent(
                model=self.chat_model,
                tools=authorized_tools,
                system_prompt=prompt_manager.get_system_prompt(persona)
            )

            # 2. Context Assembly
            context = ""
            if self.vector_store:
                try:
                    search_results = self.vector_store.similarity_search(message, k=2)
                    context = "\n".join([doc.page_content for doc in search_results])
                except Exception as e:
                    logger.error(f"RAG search failed: {e}")

            # 3. Message Assembly
            # We explicitly include the system prompt here to ensure all models (especially local ones) 
            # strictly follow the formatting and persona guidelines.
            system_message = ("system", prompt_manager.get_system_prompt(persona))
            input_messages = [system_message]
            
            for i, m in enumerate(history or []):
                if i == len(history) - 1 and m['content'] == message: continue
                # Map roles correctly to LangChain standards
                role = "assistant" if m['role'] in ['assistant', 'ai', 'bot'] else "human"
                input_messages.append((role, m['content']))
            
            current_context = f"\nContext from documentation:\n{context}\n\nUser Permissions: {user_permissions or []}"
            input_messages.append(("human", f"{current_context}\n\nUser Query: {filtered_message}"))

            # 5. Execution with Graceful Error Handling
            async def safe_stream():
                try:
                    async for chunk, metadata in agent.astream({"messages": input_messages}, stream_mode="messages", return_metadata=True):
                        # ONLY yield AI messages to the frontend to prevent raw tool JSON from leaking
                        if isinstance(chunk, AIMessage):
                            yield chunk
                except Exception as stream_e:
                    error_msg = str(stream_e)
                    logger.error(f"Streaming error: {error_msg}")
                    
                    # Construct a more helpful technical error message
                    technical_detail = "Unknown internal error."
                    if "429" in error_msg or "RESOURCE_EXHAUSTED" in error_msg:
                        technical_detail = "AI model rate limit or quota exceeded. Please wait a moment before retrying."
                    elif "timeout" in error_msg.lower():
                        technical_detail = f"The operation timed out after {settings.AGENT_TIMEOUT_SECONDS}s. The infrastructure might be under heavy load."
                    elif "authentication" in error_msg.lower() or "401" in error_msg:
                        technical_detail = "Authentication failed with the underlying AI provider."
                    else:
                        technical_detail = f"Error details: {error_msg[:200]}..."

                    yield AIMessage(content=f"⚠️ **I encountered an issue while processing your request.**\n\n**Technical Detail:** {technical_detail}\n\n*Please try again in a few moments or contact your administrator if the issue persists.*")

            return safe_stream()
        except Exception as e:
            error_msg = str(e)
            logger.error(f"Chat initialization failed: {error_msg}")
            # Return a simple generator that yields an error message
            async def error_fallback():
                yield ("error", f"System Initialization Error: {error_msg}")
            return error_fallback()

    def log_ai_action(self, user_id: str, action: str, rationale: str, payload: Dict[str, Any]):
        db = SessionLocal()
        try:
            clean_payload = SensitiveDataFilter.redact(payload)
            log_entry = AIAuditLog(user_id=user_id, action=action, rationale=rationale, payload=clean_payload, status="success")
            db.add(log_entry)
            db.commit()
        except Exception as e:
            logger.error(f"AIAuditLog failure: {e}")
            db.rollback()
        finally:
            db.close()

ai_service = AIService()
