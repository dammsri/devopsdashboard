import logging
import httpx
from typing import Dict, Any, Optional
from app.core.config import settings
from app.core.encryption import decrypt_password

logger = logging.getLogger(__name__)

class DashboardAgentService:
    """
    Orchestration service to push instructions to distributed Dashboard Agents.
    Acts as the bridge between the AI Controller and the target infrastructure.
    Uses AsyncIO/httpx for non-blocking communication.
    """
    
    def __init__(self):
        self.default_secret = settings.AGENT_SECRET

    def _resolve_agent(self, agent_id: Optional[str] = None) -> tuple:
        """Looks up an agent by its ID to get endpoint and decrypted secret."""
        if not agent_id:
            return None, self.default_secret
            
        from app.db.session import SessionLocal
        from app.models.dashboard_agent import DashboardAgent
        
        db = SessionLocal()
        try:
            agent = db.query(DashboardAgent).filter(DashboardAgent.agent_id == agent_id).first()
            if agent:
                endpoint = agent.endpoint
                if ":" not in endpoint.replace("http://", "").replace("https://", ""):
                    endpoint = f"{endpoint.rstrip('/')}:8005"
                # Decrypt the stored secret before use
                try:
                    raw_secret = decrypt_password(agent.secret)
                except Exception:
                    # Fallback if secret is stored unencrypted (legacy records)
                    raw_secret = agent.secret
                return endpoint, raw_secret
            return None, self.default_secret
        finally:
            db.close()

    async def _send_instruction(self, endpoint: str, payload: Dict[str, Any], secret: Optional[str] = None) -> Dict[str, Any]:
        """Asynchronous method to send authenticated instructions to an agent."""
        resolved_secret = secret or self.default_secret
        if not endpoint:
            return {"status": "error", "message": "Agent endpoint not resolved."}
            
        try:
            headers = {"X-Agent-Secret": resolved_secret}
            # Remove trailing slash if present
            url = f"{endpoint.rstrip('/')}/instruction"
            
            async with httpx.AsyncClient(timeout=settings.AGENT_TIMEOUT_SECONDS) as client:
                response = await client.post(url, json=payload, headers=headers)
                
                if response.status_code == 200:
                    return response.json()
                else:
                    logger.error(f"Agent instruction failed ({response.status_code}): {response.text}")
                    return {
                        "status": "error", 
                        "message": f"Agent returned status {response.status_code}",
                        "detail": response.text
                    }
        except httpx.ConnectError:
            logger.error(f"Failed to connect to agent at {endpoint}")
            return {"status": "error", "message": f"Connection failed: Could not reach agent at {endpoint}"}
        except Exception as e:
            logger.error(f"Error during agent communication at {endpoint}: {str(e)}")
            return {"status": "error", "message": f"Communication failed: {str(e)}"}

    async def send_k8s_instruction(self, k8s_env_id: str, namespace: str, service_id: str, action: str, params: Optional[Dict[str, Any]] = None, endpoint: Optional[str] = None, agent_id: Optional[str] = None) -> Dict[str, Any]:
        """Dispatches an asynchronous instruction to a K8s Cluster agent."""
        resolved_endpoint = endpoint
        resolved_secret = None
        
        if agent_id and not resolved_endpoint:
            resolved_endpoint, resolved_secret = self._resolve_agent(agent_id)
            
        payload = {
            "k8s_env_id": k8s_env_id,
            "namespace": namespace,
            "service_id": service_id,
            "action": action,
            "params": params
        }
        return await self._send_instruction(resolved_endpoint, payload, secret=resolved_secret)

    async def send_podman_instruction(self, service_name: str, action: str, params: Optional[Dict[str, Any]] = None, endpoint: Optional[str] = None, agent_id: Optional[str] = None) -> Dict[str, Any]:
        """Dispatches an asynchronous instruction to a Podman Server agent."""
        resolved_endpoint = endpoint
        resolved_secret = None
        
        if agent_id and not resolved_endpoint:
            resolved_endpoint, resolved_secret = self._resolve_agent(agent_id)
            
        payload = {
            "service_name": service_name,
            "action": action,
            "params": params
        }
        return await self._send_instruction(resolved_endpoint, payload, secret=resolved_secret)

    async def send_system_instruction(self, action: str, params: Optional[Dict[str, Any]] = None, agent_id: Optional[str] = None) -> Dict[str, Any]:
        """Dispatches an instruction to a general Infrastructure/System agent."""
        resolved_endpoint, resolved_secret = self._resolve_agent(agent_id)
        
        payload = {
            "action": action,
            "params": params
        }
        return await self._send_instruction(resolved_endpoint, payload, secret=resolved_secret)

    async def send_generic_instruction(self, agent_id: str, action: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """The most generic way to talk to any agent by ID."""
        resolved_endpoint, resolved_secret = self._resolve_agent(agent_id)
        payload = {"action": action, "params": params}
        return await self._send_instruction(resolved_endpoint, payload, secret=resolved_secret)

agent_service = DashboardAgentService()
