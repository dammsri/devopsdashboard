from fastapi import APIRouter, Depends, HTTPException
from typing import List, Dict
from app.core.dependencies import get_current_user, require_permission
from app.models.user import User
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.models.k8s import K8sEnvironment, K8sService
from app.models.audit import AuditAction
from app.core.audit import log_activity
from app.schemas.settings import K8sEnvironmentOut, K8sEnvironmentCreate, K8sEnvironmentUpdate, K8sServiceOut, K8sServiceCreate, K8sServiceUpdate

router = APIRouter(prefix="/k8s-environments", tags=["K8s Environments"])

@router.put("/{k8s_env_id}", response_model=K8sEnvironmentOut)
def update_environment(
    k8s_env_id: str, 
    payload: K8sEnvironmentUpdate, 
    db: Session = Depends(get_db), 
    current_user: User = Depends(require_permission("k8s.env.update"))
):
    env = db.query(K8sEnvironment).filter(K8sEnvironment.k8s_env_id == k8s_env_id).first()
    if not env:
        raise HTTPException(status_code=404, detail="Environment not found")
    for key, value in payload.model_dump(exclude_unset=True).items():
        setattr(env, key, value)
    db.commit()
    db.refresh(env)
    log_activity(db, current_user.user_id, AuditAction.UPDATE, "K8sEnvironment", env.k8s_env_id, f"Updated configurations for k8s environment: {env.name}")
    return env

@router.delete("/{k8s_env_id}")
def delete_environment(
    k8s_env_id: str, 
    db: Session = Depends(get_db), 
    current_user: User = Depends(require_permission("k8s.env.delete"))
):
    env = db.query(K8sEnvironment).filter(K8sEnvironment.k8s_env_id == k8s_env_id).first()
    if not env:
        raise HTTPException(status_code=404, detail="Environment not found")
    env_name = env.name
    db.delete(env)
    db.commit()
    log_activity(db, current_user.user_id, AuditAction.DELETE, "K8sEnvironment", k8s_env_id, f"Deleted k8s environment: {env_name}")
    return {"status": "success"}

@router.get("/", response_model=List[K8sEnvironmentOut])
def get_environments(db: Session = Depends(get_db), _: User = Depends(require_permission("k8s.env.view"))):
    return db.query(K8sEnvironment).all()

@router.post("/", response_model=K8sEnvironmentOut)
def create_environment(
    payload: K8sEnvironmentCreate, 
    db: Session = Depends(get_db), 
    current_user: User = Depends(require_permission("k8s.env.create"))
):
    env = K8sEnvironment(**payload.model_dump())
    db.add(env)
    db.commit()
    db.refresh(env)
    log_activity(db, current_user.user_id, AuditAction.CREATE, "K8sEnvironment", env.k8s_env_id, f"Created k8s environment: {env.name}")
    return env

# ── Services ─────────────────────────────────────────────────────────────

@router.delete("/{k8s_env_id}/services/{service_id}")
def delete_service(
    k8s_env_id: str, 
    service_id: str, 
    db: Session = Depends(get_db), 
    current_user: User = Depends(require_permission("k8s.service.delete"))
):
    svc = db.query(K8sService).filter(K8sService.k8s_env_id == k8s_env_id, K8sService.service_id == service_id).first()
    if not svc:
        raise HTTPException(status_code=404, detail="Service not found")
    svc_name = svc.name
    db.delete(svc)
    db.commit()
    log_activity(db, current_user.user_id, AuditAction.DELETE, "K8sService", f"{k8s_env_id}:{service_id}", f"Deleted k8s service {svc_name}")
    return {"status": "success"}

@router.put("/{k8s_env_id}/services/{service_id}", response_model=K8sServiceOut)
def update_service(
    k8s_env_id: str, 
    service_id: str, 
    payload: K8sServiceUpdate, 
    db: Session = Depends(get_db), 
    current_user: User = Depends(require_permission("k8s.service.update"))
):
    svc = db.query(K8sService).filter(K8sService.k8s_env_id == k8s_env_id, K8sService.service_id == service_id).first()
    if not svc:
        raise HTTPException(status_code=404, detail="Service not found")
    
    for key, value in payload.model_dump(exclude_unset=True).items():
        setattr(svc, key, value)
    
    db.commit()
    db.refresh(svc)
    log_activity(db, current_user.user_id, AuditAction.UPDATE, "K8sService", f"{k8s_env_id}:{service_id}", f"Updated configurations for k8s service {svc.name}")
    return svc

@router.get("/{k8s_env_id}/services/{service_id}")
def get_service_detail(k8s_env_id: str, service_id: str, db: Session = Depends(get_db), _: User = Depends(require_permission("k8s.service.view"))):
    svc = db.query(K8sService).filter(K8sService.k8s_env_id == k8s_env_id, K8sService.service_id == service_id).first()
    if not svc:
        raise HTTPException(status_code=404, detail="Service not found")

    # Generate pod metrics for visual consistency
    pods = [
        {
            "name": f"{service_id}-pod-{i}",
            "status": svc.status if i < 3 else "running",
            "ready": True,
            "restarts": 0,
            "age": f"{14 - i}d",
            "node": f"{k8s_env_id}-node-{(i % 3) + 1}",
        }
        for i in range(1, svc.replicas + 1)
    ]

    return {
        "id": svc.service_id,
        "k8s_env_id": k8s_env_id,
        "name": svc.name,
        "status": svc.status.capitalize(),
        "uptime": "14d 6h 22m",
        "replicas": {"desired": svc.replicas, "current": svc.replicas, "ready": svc.replicas},
        "resources": {"cpu": "250m", "memory": "512Mi"},
        "namespace": "default",
        "image": f"sc-registry.io/devops/{svc.service_id}:{svc.version or 'latest'}",
        "pods": pods[:5], # Cap at 5 for display
    }

@router.get("/services", response_model=List[K8sServiceOut])
def list_all_services(db: Session = Depends(get_db), _: User = Depends(require_permission("k8s.service.view"))):
    return db.query(K8sService).all()

@router.get("/{k8s_env_id}/services", response_model=List[K8sServiceOut])
def get_environment_services(k8s_env_id: str, db: Session = Depends(get_db), _: User = Depends(require_permission("k8s.service.view"))):
    return db.query(K8sService).filter(K8sService.k8s_env_id == k8s_env_id).all()

@router.post("/{k8s_env_id}/services", response_model=K8sServiceOut)
def create_service(
    k8s_env_id: str,
    payload: K8sServiceCreate, 
    db: Session = Depends(get_db), 
    current_user: User = Depends(require_permission("k8s.service.create"))
):
    # Ensure payload k8s_env_id matches path if both provided
    data = payload.model_dump()
    data['k8s_env_id'] = k8s_env_id
    svc = K8sService(**data)
    db.add(svc)
    db.commit()
    db.refresh(svc)
    log_activity(db, current_user.user_id, AuditAction.CREATE, "K8sService", f"{svc.k8s_env_id}:{svc.service_id}", f"Deployed k8s service {svc.name} in environment {k8s_env_id}")
    return svc
