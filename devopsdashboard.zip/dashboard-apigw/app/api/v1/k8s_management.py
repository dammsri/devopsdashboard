from fastapi import APIRouter, Depends, HTTPException
from typing import List
from app.core.dependencies import get_current_user, require_permission
from app.models.user import User
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.models.k8s import K8sCluster, K8sNamespace, K8sEnvironment, K8sService
from app.models.audit import AuditAction
from app.core.audit import log_activity
from app.schemas.settings import (
    K8sClusterOut, K8sClusterCreate, K8sClusterUpdate,
    K8sNamespaceOut, K8sNamespaceCreate, K8sNamespaceUpdate,
    K8sEnvironmentOut, K8sEnvironmentCreate, K8sEnvironmentUpdate,
    K8sServiceOut, K8sServiceCreate, K8sServiceUpdate
)
from app.core.encryption import encrypt_password

router = APIRouter(prefix="/k8s", tags=["K8s Management"])

# ── Clusters ──────────────────────────────────────────────────────────────────

@router.get("/clusters", response_model=List[K8sClusterOut])
def list_clusters(db: Session = Depends(get_db), _: User = Depends(require_permission("k8s.cluster.view"))):
    return db.query(K8sCluster).all()

@router.post("/clusters", response_model=K8sClusterOut)
def create_cluster(
    payload: K8sClusterCreate, 
    db: Session = Depends(get_db), 
    current_user: User = Depends(require_permission("k8s.cluster.create"))
):
    data = payload.model_dump()
    if data.get("password"):
        data["password"] = encrypt_password(data["password"])
    
    cluster = K8sCluster(**data)
    db.add(cluster)
    db.commit()
    db.refresh(cluster)
    log_activity(db, current_user.user_id, AuditAction.CREATE, "K8sCluster", f"{cluster.itam_id}:{cluster.cluster_id}", f"Created k8s cluster: {cluster.cluster_id}")
    return cluster

@router.put("/clusters/{itam_id}/{cluster_id}", response_model=K8sClusterOut)
def update_cluster(
    itam_id: int,
    cluster_id: str,
    payload: K8sClusterUpdate, 
    db: Session = Depends(get_db), 
    current_user: User = Depends(require_permission("k8s.cluster.update"))
):
    cluster = db.query(K8sCluster).filter(K8sCluster.itam_id == itam_id, K8sCluster.cluster_id == cluster_id).first()
    if not cluster:
        raise HTTPException(status_code=404, detail="Cluster not found")
    
    update_data = payload.model_dump(exclude_unset=True)
    if "password" in update_data and update_data["password"]:
        update_data["password"] = encrypt_password(update_data["password"])
    elif "password" in update_data:
        del update_data["password"] # Don't overwrite with empty string
        
    for key, value in update_data.items():
        setattr(cluster, key, value)
        
    db.commit()
    db.refresh(cluster)
    log_activity(db, current_user.user_id, AuditAction.UPDATE, "K8sCluster", f"{itam_id}:{cluster_id}", f"Updated k8s cluster configurations for: {cluster_id}")
    return cluster

@router.delete("/clusters/{itam_id}/{cluster_id}")
def delete_cluster(
    itam_id: int,
    cluster_id: str,
    db: Session = Depends(get_db), 
    current_user: User = Depends(require_permission("k8s.cluster.delete"))
):
    cluster = db.query(K8sCluster).filter(K8sCluster.itam_id == itam_id, K8sCluster.cluster_id == cluster_id).first()
    if not cluster:
        raise HTTPException(status_code=404, detail="Cluster not found")
    db.delete(cluster)
    db.commit()
    log_activity(db, current_user.user_id, AuditAction.DELETE, "K8sCluster", f"{itam_id}:{cluster_id}", f"Deleted k8s cluster: {cluster_id}")
    return {"status": "success"}

# ── Namespaces ────────────────────────────────────────────────────────────────

@router.get("/namespaces", response_model=List[K8sNamespaceOut])
def list_namespaces(db: Session = Depends(get_db), _: User = Depends(require_permission("k8s.cluster.view"))):
    return db.query(K8sNamespace).all()

@router.post("/namespaces", response_model=K8sNamespaceOut)
def create_namespace(
    payload: K8sNamespaceCreate, 
    db: Session = Depends(get_db), 
    current_user: User = Depends(require_permission("k8s.cluster.create"))
):
    ns = K8sNamespace(**payload.model_dump())
    db.add(ns)
    db.commit()
    db.refresh(ns)
    log_activity(db, current_user.user_id, AuditAction.CREATE, "K8sNamespace", f"{ns.itam_id}:{ns.namespace}", f"Registered k8s namespace: {ns.namespace}")
    return ns

@router.put("/namespaces/{itam_id}/{cluster_id}/{k8s_env_id}/{namespace}", response_model=K8sNamespaceOut)
def update_namespace(
    itam_id: int,
    cluster_id: str,
    k8s_env_id: str,
    namespace: str,
    payload: K8sNamespaceUpdate, 
    db: Session = Depends(get_db), 
    current_user: User = Depends(require_permission("k8s.cluster.update"))
):
    ns = db.query(K8sNamespace).filter(
        K8sNamespace.itam_id == itam_id,
        K8sNamespace.cluster_id == cluster_id,
        K8sNamespace.k8s_env_id == k8s_env_id,
        K8sNamespace.namespace == namespace
    ).first()
    if not ns:
        raise HTTPException(status_code=404, detail="Namespace not found")
    
    for key, value in payload.model_dump(exclude_unset=True).items():
        setattr(ns, key, value)
        
    db.commit()
    db.refresh(ns)
    log_activity(db, current_user.user_id, AuditAction.UPDATE, "K8sNamespace", f"{itam_id}:{cluster_id}:{k8s_env_id}:{namespace}", f"Updated k8s namespace details for: {namespace}")
    return ns

@router.delete("/namespaces/{itam_id}/{cluster_id}/{k8s_env_id}/{namespace}")
def delete_namespace(
    itam_id: int,
    cluster_id: str,
    k8s_env_id: str,
    namespace: str,
    db: Session = Depends(get_db), 
    current_user: User = Depends(require_permission("k8s.cluster.delete"))
):
    ns = db.query(K8sNamespace).filter(
        K8sNamespace.itam_id == itam_id,
        K8sNamespace.cluster_id == cluster_id,
        K8sNamespace.k8s_env_id == k8s_env_id,
        K8sNamespace.namespace == namespace
    ).first()
    if not ns:
        raise HTTPException(status_code=404, detail="Namespace not found")
    db.delete(ns)
    db.commit()
    log_activity(db, current_user.user_id, AuditAction.DELETE, "K8sNamespace", f"{itam_id}:{cluster_id}:{k8s_env_id}:{namespace}", f"Deleted k8s namespace: {namespace}")
    return {"status": "success"}

# ── Environments ─────────────────────────────────────────────────────────────

@router.get("/environments", response_model=List[K8sEnvironmentOut])
def list_environments(db: Session = Depends(get_db), _: User = Depends(require_permission("k8s.env.view"))):
    return db.query(K8sEnvironment).all()

@router.post("/environments", response_model=K8sEnvironmentOut)
def create_environment(
    payload: K8sEnvironmentCreate, 
    db: Session = Depends(get_db), 
    current_user: User = Depends(require_permission("k8s.env.create"))
):
    env = K8sEnvironment(**payload.model_dump())
    db.add(env)
    db.commit()
    db.refresh(env)
    log_activity(db, current_user.user_id, AuditAction.CREATE, "K8sEnvironment", f"{env.cluster_id}:{env.k8s_env_id}", f"Created k8s environment: {env.name}")
    return env

@router.put("/environments/{itam_id}/{cluster_id}/{k8s_env_id}", response_model=K8sEnvironmentOut)
def update_environment(
    itam_id: int,
    cluster_id: str,
    k8s_env_id: str,
    payload: K8sEnvironmentUpdate, 
    db: Session = Depends(get_db), 
    current_user: User = Depends(require_permission("k8s.env.update"))
):
    env = db.query(K8sEnvironment).filter(
        K8sEnvironment.itam_id == itam_id,
        K8sEnvironment.cluster_id == cluster_id,
        K8sEnvironment.k8s_env_id == k8s_env_id
    ).first()
    if not env:
        raise HTTPException(status_code=404, detail="Environment not found")
    
    for key, value in payload.model_dump(exclude_unset=True).items():
        setattr(env, key, value)
        
    db.commit()
    db.refresh(env)
    log_activity(db, current_user.user_id, AuditAction.UPDATE, "K8sEnvironment", f"{cluster_id}:{k8s_env_id}", f"Updated k8s environment: {env.name}")
    return env

@router.delete("/environments/{itam_id}/{cluster_id}/{k8s_env_id}")
def delete_environment(
    itam_id: int,
    cluster_id: str,
    k8s_env_id: str,
    db: Session = Depends(get_db), 
    current_user: User = Depends(require_permission("k8s.env.delete"))
):
    env = db.query(K8sEnvironment).filter(
        K8sEnvironment.itam_id == itam_id,
        K8sEnvironment.cluster_id == cluster_id,
        K8sEnvironment.k8s_env_id == k8s_env_id
    ).first()
    if not env:
        raise HTTPException(status_code=404, detail="Environment not found")
    db.delete(env)
    db.commit()
    log_activity(db, current_user.user_id, AuditAction.DELETE, "K8sEnvironment", f"{cluster_id}:{k8s_env_id}", f"Deleted k8s environment: {env.name}")
    return {"status": "success"}

@router.get("/environments/{k8s_env_id}/services", response_model=List[K8sServiceOut])
def get_environment_services(k8s_env_id: str, db: Session = Depends(get_db), _: User = Depends(require_permission("k8s.service.view"))):
    """Returns all services belonging to a specific k8s environment."""
    return db.query(K8sService).filter(K8sService.k8s_env_id == k8s_env_id).all()

# ── Services ─────────────────────────────────────────────────────────────────

@router.get("/services", response_model=List[K8sServiceOut])
def list_services(db: Session = Depends(get_db), _: User = Depends(require_permission("k8s.service.view"))):
    return db.query(K8sService).all()

@router.post("/services", response_model=K8sServiceOut)
def create_service(
    payload: K8sServiceCreate, 
    db: Session = Depends(get_db), 
    current_user: User = Depends(require_permission("k8s.service.create"))
):
    svc = K8sService(**payload.model_dump())
    db.add(svc)
    db.commit()
    db.refresh(svc)
    log_activity(db, current_user.user_id, AuditAction.CREATE, "K8sService", f"{svc.k8s_env_id}:{svc.service_id}", f"Deployed k8s service: {svc.name}")
    return svc

@router.delete("/services/{itam_id}/{cluster_id}/{k8s_env_id}/{namespace}/{service_id}")
def delete_service(
    itam_id: int,
    cluster_id: str,
    k8s_env_id: str,
    namespace: str,
    service_id: str,
    db: Session = Depends(get_db), 
    current_user: User = Depends(require_permission("k8s.service.delete"))
):
    svc = db.query(K8sService).filter(
        K8sService.itam_id == itam_id,
        K8sService.cluster_id == cluster_id,
        K8sService.k8s_env_id == k8s_env_id,
        K8sService.namespace == namespace,
        K8sService.service_id == service_id
    ).first()
    if not svc:
        raise HTTPException(status_code=404, detail="Service not found")
    db.delete(svc)
    db.commit()
    log_activity(db, current_user.user_id, AuditAction.DELETE, "K8sService", f"{itam_id}:{cluster_id}:{k8s_env_id}:{namespace}:{service_id}", f"Deleted k8s service: {svc.name}")
    return {"status": "success"}

@router.put("/services/{itam_id}/{cluster_id}/{k8s_env_id}/{namespace}/{service_id}", response_model=K8sServiceOut)
def update_service(
    itam_id: int,
    cluster_id: str,
    k8s_env_id: str,
    namespace: str,
    service_id: str,
    payload: K8sServiceUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_permission("k8s.service.update"))
):
    svc = db.query(K8sService).filter(
        K8sService.itam_id == itam_id,
        K8sService.cluster_id == cluster_id,
        K8sService.k8s_env_id == k8s_env_id,
        K8sService.namespace == namespace,
        K8sService.service_id == service_id
    ).first()
    if not svc:
        raise HTTPException(status_code=404, detail="Service not found")
    
    for key, value in payload.model_dump(exclude_unset=True).items():
        setattr(svc, key, value)
        
    db.commit()
    db.refresh(svc)
    log_activity(db, current_user.user_id, AuditAction.UPDATE, "K8sService", f"{itam_id}:{cluster_id}:{k8s_env_id}:{namespace}:{service_id}", f"Updated k8s service: {svc.name}")
    return svc

@router.get("/services/{k8s_env_id}/{service_id}", response_model=K8sServiceOut)
def get_service_detail(k8s_env_id: str, service_id: str, db: Session = Depends(get_db), _: User = Depends(require_permission("k8s.service.view"))):
    """Returns details for a specific k8s service."""
    svc = db.query(K8sService).filter(K8sService.k8s_env_id == k8s_env_id, K8sService.service_id == service_id).first()
    if not svc:
        raise HTTPException(status_code=404, detail="k8s Service not found")
    return svc
