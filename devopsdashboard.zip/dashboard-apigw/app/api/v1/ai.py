import json
import logging
from typing import List, Dict, Any
from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException, Body, Request
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.services.ai_service import ai_service
from app.api.v1.auth import get_current_user
from app.core.dependencies import require_permission
from app.models.user import User
from app.models.ai import AIConversation, AIChatMessage
from app.core.limiter import limiter

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/ai")


@router.get("/conversations")
async def get_conversations(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """List all AI conversations for the current user."""
    conversations = db.query(AIConversation)\
        .filter(AIConversation.user_id == current_user.user_id)\
        .order_by(AIConversation.updated_at.desc())\
        .all()
    
    return [
        {
            "id": c.id,
            "title": c.title,
            "updated_at": c.updated_at,
            "created_at": c.created_at
        } for c in conversations
    ]


@router.get("/conversations/{conversation_id}")
async def get_conversation_details(
    conversation_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Retrieve message history for a specific conversation."""
    conversation = db.query(AIConversation)\
        .filter(AIConversation.id == conversation_id, AIConversation.user_id == current_user.user_id)\
        .first()
    
    if not conversation:
        raise HTTPException(status_code=404, detail="Conversation not found")
    
    messages = db.query(AIChatMessage)\
        .filter(AIChatMessage.conversation_id == conversation_id)\
        .order_by(AIChatMessage.timestamp.asc())\
        .all()
    
    return {
        "id": conversation.id,
        "title": conversation.title,
        "messages": [
            {
                "role": m.role,
                "content": m.content,
                "timestamp": m.timestamp
            } for m in messages
        ]
    }


@router.delete("/conversations/{conversation_id}")
async def delete_conversation(
    conversation_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Delete a conversation and its messages."""
    conversation = db.query(AIConversation)\
        .filter(AIConversation.id == conversation_id, AIConversation.user_id == current_user.user_id)\
        .first()
    
    if not conversation:
        raise HTTPException(status_code=404, detail="Conversation not found")
    
    db.delete(conversation)
    db.commit()
    return {"status": "success", "message": "Conversation deleted"}


@router.post("/chat")
@limiter.limit("10/minute")
async def chat(
    request: Request,
    message: str = Body(..., embed=True),
    conversation_id: int = Body(None, embed=True),
    history: List[Dict[str, Any]] = Body(None, embed=True),
    current_user: User = Depends(require_permission("ai.chat")),
    db: Session = Depends(get_db)
):
    """
    Chat with the DevOps Copilot.
    Automagically manages and persists conversations.
    """
    if not ai_service.enabled:
        raise HTTPException(status_code=503, detail="AI Service is disabled. Check API Key.")

    # 1. Handle Conversation Persistence
    active_conv = None
    if conversation_id:
        active_conv = db.query(AIConversation).filter(
            AIConversation.id == conversation_id, 
            AIConversation.user_id == current_user.user_id
        ).first()
    
    if not active_conv:
        # Create a new conversation
        # Use first 30 chars of message as title
        title = (message[:27] + "...") if len(message) > 30 else message
        active_conv = AIConversation(user_id=current_user.user_id, title=title)
        db.add(active_conv)
        db.flush() # Get the ID for the message
    
    # 2. Save User Message
    db.add(AIChatMessage(conversation_id=active_conv.id, role="human", content=message))
    db.commit()

    async def event_generator():
        ai_full_response = ""
        try:
            # Flatten permissions
            user_permissions = []
            for role in current_user.roles:
                for func in role.functionalities:
                    user_permissions.append(func.name)
            
            # Send conversation ID in metadata
            yield f"data: {json.dumps({'conversation_id': active_conv.id, 'title': active_conv.title})}\n\n"

            stream = await ai_service.chat(message, history, user_permissions=user_permissions)
            async for chunk in stream:
                try:
                    if isinstance(chunk, tuple) and len(chunk) >= 1:
                        chunk_obj = chunk[0]
                    else:
                        chunk_obj = chunk
                    
                    content = getattr(chunk_obj, 'content', None)
                    if not content and isinstance(chunk_obj, dict):
                        if 'messages' in chunk_obj and chunk_obj['messages']:
                            last_msg = chunk_obj['messages'][-1]
                            content = getattr(last_msg, 'content', None) or (last_msg.get('content') if isinstance(last_msg, dict) else None)
                        else:
                            content = chunk_obj.get('content')

                    if isinstance(content, list):
                        text_parts = []
                        for part in content:
                            if isinstance(part, dict) and 'text' in part:
                                text_parts.append(part['text'])
                            elif isinstance(part, str):
                                text_parts.append(part)
                        content = "".join(text_parts)

                    if content is not None and content != "":
                        ai_full_response += str(content)
                        yield f"data: {json.dumps({'content': str(content)})}\n\n"
                except Exception as chunk_err:
                    logger.error(f"Error processing chunk: {chunk_err}")
                    continue
            
            # 3. Save AI Message at the end of the stream
            if ai_full_response:
                # Use a fresh session for background save to avoid closing generator's session
                # but for simplicity in this dev env, we use the injected db
                db.add(AIChatMessage(
                    conversation_id=active_conv.id, 
                    role="ai", 
                    content=ai_full_response
                ))
                active_conv.updated_at = datetime.now(timezone.utc)
                db.commit()

        except Exception as e:
            logger.error(f"AI Chat Error: {str(e)}", exc_info=True)
            yield f"data: {json.dumps({'error': str(e)})}\n\n"

    return StreamingResponse(event_generator(), media_type="text/event-stream")

@router.get("/insights")
@limiter.limit("5/minute")
async def get_insights(request: Request, current_user: User = Depends(require_permission("ai.diagnose"))):
    """
    Get proactive AI-generated infrastructure insights.
    """
    if not ai_service.enabled:
        return {"insights": ["AI Service disabled. Provide API key to enable insights."]}

    # Mock sample for now, will be connected to telemetry in Phase 2
    prompt = "Based on the infrastructure, generate 3 proactive maintenance suggestions for a DevOps dashboard."
    try:
        response = ai_service.insights_model.invoke(prompt)
        content = getattr(response, 'content', None)
        if not content and isinstance(response, dict):
            content = response.get('content', '')
            
        return {"insights": content.split("\n") if content else []}
    except Exception as e:
        logger.error(f"Error in insights: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/execute")
async def execute_action(
    action: str = Body(..., embed=True),
    rationale: str = Body(..., embed=True),
    payload: Dict[str, Any] = Body(..., embed=True),
    current_user: User = Depends(require_permission("ai.remediate")),
    db: Session = Depends(get_db)
):
    """
    Securely execute an AI-suggested action after user confirmation.
    Logs the action to the audit trail.
    """
    # 1. Audit Log the attempt
    ai_service.log_ai_action(
        user_id=current_user.user_id,
        action=action,
        rationale=rationale,
        payload=payload
    )

    # 2. Logic to actually perform the action
    # This will be expanded as we define "tools" for the agent.
    # For now, it's a secured execution skeleton.
    
    if action == "RESTART_SERVICE":
        # Placeholder for actual service restart logic
        return {"status": "success", "message": f"Action {action} executed and logged."}
    
    return {"status": "unsupported", "message": f"Action {action} is not yet implemented."}


@router.post("/ingest/url")
async def ingest_url(
    url: str = Body(..., embed=True),
    current_user: User = Depends(require_permission("sys.security.manage"))
):
    """
    Ingest a URL into the persistent vector store.
    Limited to administrators.
    """
    try:
        result = await ai_service.ingest_url(url)
        return result
    except Exception as e:
        logger.error(f"URL Ingestion error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/ingest/file")
async def ingest_file(
    file: bytes = Body(...),
    filename: str = Body(...),
    current_user: User = Depends(require_permission("sys.security.manage"))
):
    """
    Ingest a file into the persistent vector store.
    Saves to a temporary location before processing.
    """
    import tempfile
    import os
    
    # Create temp file to use with LangChain loaders
    suffix = os.path.splitext(filename)[1]
    with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
        tmp.write(file)
        tmp_path = tmp.name
        
    try:
        result = await ai_service.ingest_file(tmp_path)
        return result
    except Exception as e:
        logger.error(f"File Ingestion error: {e}")
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        if os.path.exists(tmp_path):
            os.remove(tmp_path)
