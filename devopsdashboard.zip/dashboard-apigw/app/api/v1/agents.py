from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List, Optional
from pydantic import BaseModel
from datetime import datetime

from app.db.session import get_db
from app.models.dashboard_agent import DashboardAgent
from app.models.application import Application
from app.core.dependencies import get_current_user, require_permission
from app.models.user import User
from app.core.encryption import encrypt_password

router = APIRouter(prefix="/settings/agents", tags=["Dashboard Agents"])

# ── Schemas ───────────────────────────────────────────────────────────────────

class AgentBase(BaseModel):
    agent_id: str
    name: str
    type: str # K8S, PODMAN
    endpoint: str
    secret: str
    itam_id: int
    description: Optional[str] = None

class AgentCreate(AgentBase):
    pass

class AgentUpdate(BaseModel):
    name: Optional[str] = None
    endpoint: Optional[str] = None
    secret: Optional[str] = None
    status: Optional[str] = None
    description: Optional[str] = None

class AgentOut(BaseModel):
    id: int
    agent_id: str
    name: str
    type: str
    endpoint: str
    itam_id: int
    status: str
    last_heard: Optional[datetime] = None
    description: Optional[str] = None
    # secret is intentionally excluded from API responses
    
    class Config:
        from_attributes = True

# ── Endpoints ─────────────────────────────────────────────────────────────────

@router.get("/", response_model=List[AgentOut])
def list_agents(db: Session = Depends(get_db), _: User = Depends(require_permission("sys.agents.view"))):
    """List all registered dashboard agents."""
    return db.query(DashboardAgent).all()

@router.post("/", response_model=AgentOut, status_code=status.HTTP_201_CREATED)
def create_agent(
    agent_in: AgentCreate, 
    db: Session = Depends(get_db), 
    current_user: User = Depends(require_permission("sys.agents.create"))
):
    """Register a new dashboard agent."""
    # Verify Application exists
    app = db.query(Application).filter(Application.itam_id == agent_in.itam_id).first()
    if not app:
        raise HTTPException(status_code=404, detail=f"Application with ITAM ID {agent_in.itam_id} not found")
        
    # Check for duplicate agent_id
    existing = db.query(DashboardAgent).filter(DashboardAgent.agent_id == agent_in.agent_id).first()
    if existing:
        raise HTTPException(status_code=400, detail="Agent ID already exists")

    new_agent = DashboardAgent(**agent_in.dict())
    new_agent.secret = encrypt_password(agent_in.secret)  # Encrypt before storing
    db.add(new_agent)
    db.commit()
    db.refresh(new_agent)
    return new_agent

@router.put("/{agent_id_internal}", response_model=AgentOut)
def update_agent(
    agent_id_internal: int, 
    agent_in: AgentUpdate, 
    db: Session = Depends(get_db), 
    current_user: User = Depends(require_permission("sys.agents.update"))
):
    """Update an existing dashboard agent configuration."""
    agent = db.query(DashboardAgent).filter(DashboardAgent.id == agent_id_internal).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    
    update_data = agent_in.dict(exclude_unset=True)
    for field, value in update_data.items():
        if field == "secret" and value:
            setattr(agent, field, encrypt_password(value))  # Encrypt new secret
        else:
            setattr(agent, field, value)
    
    db.commit()
    db.refresh(agent)
    return agent

@router.delete("/{agent_id_internal}", status_code=status.HTTP_204_NO_CONTENT)
def delete_agent(
    agent_id_internal: int, 
    db: Session = Depends(get_db), 
    current_user: User = Depends(require_permission("sys.agents.delete"))
):
    """Deregister a dashboard agent."""
    agent = db.query(DashboardAgent).filter(DashboardAgent.id == agent_id_internal).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    
    db.delete(agent)
    db.commit()
    return None
