from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import field_validator
from functools import lru_cache
from typing import List, Any, Union, Optional


class Settings(BaseSettings):
    # App
    APP_NAME: str = "DevOps Dashboard"
    APP_VERSION: str = "1.0.0"
    DEBUG: bool = False
    ORGANIZATION_NAME: str = "DevOps Organization"
    
    # Logging
    LOG_LEVEL: str = "INFO"
    LOG_DIR: str = "logs"
    SERVICE_NAME: str = "api-gateway"
    
    # Auth Mode
    AUTH_MODE: str = "LOCAL" # LOCAL or ACTIVE_DIRECTORY (AD)

    # AI Configuration
    AI_PROVIDER: str = "gemini"  # "openai", "gemini", or "ollama"
    AI_SENSITIVE_FIELDS: Union[List[str], str] = ["password", "secret", "token", "key"]

    # OpenAI
    OPENAI_API_KEY: str = ""
    OPENAI_MODEL: str = "gpt-4o-mini"
    OPENAI_INSIGHTS_MODEL: str = "gpt-4o"

    # Gemini
    GEMINI_API_KEY: str = ""
    GEMINI_CHAT_MODEL: str = "gemini-2.0-flash"
    GEMINI_INSIGHTS_MODEL: str = "gemini-2.0-flash"
    GEMINI_EMBEDDING_MODEL: str = "models/text-embedding-004"

    # Ollama (Local)
    OLLAMA_BASE_URL: str = "http://localhost:11434"
    OLLAMA_CHAT_MODEL: str = "llama3"
    OLLAMA_INSIGHTS_MODEL: str = "llama3"
    OLLAMA_EMBEDDING_MODEL: str = "nomic-embed-text"
    
    # Vector Store
    CHROMA_DB_PATH: str = "./storage/chroma_db"

    @field_validator("AI_SENSITIVE_FIELDS", mode="before")
    @classmethod
    def split_sensitive_fields(cls, v: Any) -> List[str]:
        if isinstance(v, str):
            return [s.strip() for s in v.split(",") if s.strip()]
        return v

    # Security — NO DEFAULTS: these must be set explicitly in .env
    SECRET_KEY: str
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 15
    REFRESH_TOKEN_EXPIRE_DAYS: int = 7
    ENCRYPTION_KEY: str  # Valid 32-byte Fernet key — generate with: python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"

    # Database
    DB_TYPE: str = "sqlite" # sqlite or postgresql
    DB_USER: Optional[str] = None
    DB_PASSWORD: Optional[str] = None
    DB_HOST: Optional[str] = "localhost"
    DB_PORT: Optional[str] = None
    DB_NAME: Optional[str] = "devopsdashboard"
    DATABASE_URL: Optional[str] = None

    @field_validator("DATABASE_URL", mode="before")
    @classmethod
    def assemble_db_url(cls, v: Optional[str], info: Any) -> Any:
        if v:
            return v
        
        # Accessing other fields via the values dict in info
        values = info.data
        db_type = values.get("DB_TYPE", "sqlite").lower()
        
        if db_type == "sqlite":
            return f"sqlite:///./{values.get('DB_NAME', 'devopsdashboard')}.db"
        
        # PostgreSQL construction
        user = values.get("DB_USER")
        password = values.get("DB_PASSWORD")
        host = values.get("DB_HOST", "localhost")
        port = values.get("DB_PORT", "5432")
        name = values.get("DB_NAME", "devopsdashboard")
        
        if not all([user, password, name]):
            # Fallback to sqlite if postgres info is incomplete
            return "sqlite:///./devopsdashboard.db"
            
        return f"postgresql://{user}:{password}@{host}:{port}/{name}"

    # Active Directory / LDAP
    AD_SERVER: str = "ldap://localhost:389"
    AD_DOMAIN: str = "example.com"
    AD_BASE_DN: str = "dc=example,dc=com"
    AD_USER_DN_TEMPLATE: str = "uid={user_id},ou=users,{base_dn}" # Customized for the specific AD/LDAP layout

    # CORS
    CORS_ORIGINS: List[str] = ["http://localhost:3000", "http://localhost:5173"]

    # Dashboard Agents — NO DEFAULT: must be set in .env
    AGENT_SECRET: str
    
    # Podman Agent
    AGENT_PODMAN_ENABLED: bool = True
    AGENT_PODMAN_INTERVAL_MINS: int = 5
    AGENT_PODMAN_URL: str = "http://localhost:8001"
    
    # K8s Agent
    AGENT_K8S_ENABLED: bool = True
    AGENT_K8S_INTERVAL_MINS: int = 5
    AGENT_K8S_URL: str = "http://localhost:8002"
    AGENT_K8S_ENV_ID: str = "cl-apac-01"
    
    # Agent Communication
    AGENT_TIMEOUT_SECONDS: float = 20.0

    model_config = SettingsConfigDict(
        env_file=".env",
        case_sensitive=True,
        env_parse_list_separator=","
    )


@lru_cache()
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
