from typing import Optional, List, Set
from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session
from app.core.security import decode_token
from app.db.session import get_db
from app.models.user import User

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/v1/auth/login")


def get_current_user(
    token: str = Depends(oauth2_scheme),
    db: Session = Depends(get_db),
) -> User:
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    payload = decode_token(token)
    if payload is None:
        raise credentials_exception

    token_type = payload.get("type")
    if token_type != "access":
        raise credentials_exception

    user_id: Optional[str] = payload.get("sub")
    if user_id is None:
        raise credentials_exception

    # Fetch user and their roles/functionalities
    user = db.query(User).filter(User.user_id == user_id).first()
    if user is None or not user.is_active:
        raise credentials_exception
    return user


def require_permission(slug: str):
    """
    Dependency factory to enforce granular permission-based access control.
    """
    def permission_checker(current_user: User = Depends(get_current_user)) -> User:
        # Flatten user permissions from many-to-many relationship
        user_permissions: Set[str] = set()
        for role in current_user.roles:
            for func in role.functionalities:
                user_permissions.add(func.name)
        
        if slug in user_permissions:
            return current_user
        
        # 1. Check for wildcard .manage (e.g., if slug is 'infra.app.view', check 'infra.app.manage')
        if '.' in slug:
            category_prefix = slug.rsplit('.', 1)[0]
            manage_slug = f"{category_prefix}.manage"
            if manage_slug in user_permissions:
                return current_user
        
        # 2. Check for system management override (only for system-related permissions)
        if slug.startswith("sys.") and "sys.security.manage" in user_permissions:
            return current_user
            
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=f"Access denied. Missing required permission: {slug}",
        )
    return permission_checker
