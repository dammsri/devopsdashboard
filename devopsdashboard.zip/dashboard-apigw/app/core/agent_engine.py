from app.core.logging_config import setup_logging
import requests
from datetime import datetime, timezone
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.interval import IntervalTrigger
from sqlalchemy.orm import Session
from app.db.session import SessionLocal
from app.models.infrastructure import Server, Service
from app.models.k8s import K8sEnvironment, K8sService
from app.models.dashboard_agent import DashboardAgent
from app.core.config import settings
from app.core.encryption import decrypt_password

# Dedicated loggers for the agent engine
k8s_logger = setup_logging("agent-k8s", "agent-k8s.log")
podman_logger = setup_logging("agent-podman", "agent-podman.log")
infra_logger = setup_logging("agent-infra", "agent-infra.log")

# Global scheduler instance
scheduler = BackgroundScheduler()

def fetch_podman_metrics():
    """
    Dynamic job to pull metrics from agents registered as PODMAN.
    """
    db: Session = SessionLocal()
    try:
        agents = db.query(DashboardAgent).filter(DashboardAgent.type == "PODMAN").all()
        for agent in agents:
            try:
                # Decrypt secret for use in header
                try:
                    raw_secret = decrypt_password(agent.secret)
                except Exception:
                    raw_secret = agent.secret # Fallback for unencrypted dev data
                
                headers = {"X-Agent-Secret": raw_secret}
                # Standardized port 8005 fallback
                url = agent.endpoint
                if ":" not in url.replace("http://", "").replace("https://", ""):
                    url = f"{url.rstrip('/')}:8005"
                
                response = requests.get(f"{url}/metrics", headers=headers, timeout=10)
                
                if response.status_code == 200:
                    data = response.json()
                    agent.status = "healthy"
                    agent.last_heard = datetime.now(timezone.utc)
                    
                    # Update all Servers associated with this Agent's ITAM ID
                    servers = db.query(Server).filter(Server.itam_id == agent.itam_id).all()
                    for server in servers:
                        server.cpu_usage = data.get("host", {}).get("cpu_usage", 0)
                        server.mem_usage = data.get("host", {}).get("mem_usage", 0)
                        server.patch_level = data.get("host", {}).get("patch_level", "Unknown")
                        server.last_heard = datetime.now(timezone.utc)
                        server.status = "Online"
                        
                        # Update Container Services
                        for container in data.get("containers", []):
                            service = db.query(Service).filter(
                                Service.itam_id == server.itam_id,
                                Service.name == container["name"]
                            ).first()
                            if service:
                                service.current_image = container["image"]
                                service.health_status = container["health"]
                                service.status = container["status"]
                                service.telemetry_metadata = container
                    
                    podman_logger.info(f"📊 Updated Podman metrics via agent: {agent.agent_id}")
                else:
                    agent.status = "down"
                    podman_logger.warning(f"⚠️ Agent {agent.agent_id} at {agent.endpoint} returned {response.status_code}")
                    
            except Exception as e:
                agent.status = "down"
                podman_logger.error(f"❌ Error polling agent {agent.agent_id}: {str(e)}")
        
        db.commit()
    finally:
        db.close()

def fetch_k8s_metrics():
    """
    Dynamic job to pull metrics from agents registered as K8S.
    """
    db: Session = SessionLocal()
    try:
        agents = db.query(DashboardAgent).filter(DashboardAgent.type == "K8S").all()
        for agent in agents:
            try:
                # Discover all environments for this application
                environments = db.query(K8sEnvironment).filter(K8sEnvironment.itam_id == agent.itam_id).all()
                if not environments:
                    continue
                
                agent_reachable = False
                # Decrypt secret for use in header
                try:
                    raw_secret = decrypt_password(agent.secret)
                except Exception:
                    raw_secret = agent.secret
                
                headers = {"X-Agent-Secret": raw_secret}
                
                # Standardized port 8005 fallback
                base_url = agent.endpoint
                if ":" not in base_url.replace("http://", "").replace("https://", ""):
                    base_url = f"{base_url.rstrip('/')}:8005"

                for env in environments:
                    try:
                        response = requests.get(
                            f"{base_url}/environment/{env.k8s_env_id}/services", 
                            headers=headers, 
                            timeout=10
                        )
                        
                        if response.status_code == 200:
                            agent_reachable = True
                            services_data = response.json()
                            for s_data in services_data:
                                k8sservice = db.query(K8sService).filter(
                                    K8sService.itam_id == env.itam_id,
                                    K8sService.cluster_id == env.cluster_id,
                                    K8sService.k8s_env_id == env.k8s_env_id,
                                    K8sService.namespace == s_data["namespace"],
                                    K8sService.service_id == s_data["service_id"]
                                ).first()
                                
                                if k8sservice:
                                    k8sservice.current_image = s_data["current_image"]
                                    k8sservice.last_deployed_at = datetime.fromisoformat(s_data["last_deployed_at"].replace('Z', '+00:00'))
                                    k8sservice.health_status = s_data["health_status"]
                                    k8sservice.status = s_data["status"]
                            
                            k8s_logger.info(f"☸️ Updated k8s env {env.k8s_env_id} via agent {agent.agent_id}")
                    except Exception as env_e:
                        k8s_logger.error(f"❌ Error polling k8s env {env.k8s_env_id} on agent {agent.agent_id}: {str(env_e)}")

                if agent_reachable:
                    agent.status = "healthy"
                    agent.last_heard = datetime.now(timezone.utc)
                else:
                    agent.status = "down"
                
                db.commit()
            except Exception as e:
                k8s_logger.error(f"❌ Critical error for k8s agent {agent.agent_id}: {str(e)}")
        
    finally:
        db.close()

def fetch_infra_metrics():
    """
    Dynamic job to pull host metrics from agents registered as INFRA or SYSTEM.
    """
    db: Session = SessionLocal()
    try:
        agents = db.query(DashboardAgent).filter(DashboardAgent.type.in_(["INFRA", "SYSTEM"])).all()
        for agent in agents:
            try:
                # Decrypt secret
                try:
                    raw_secret = decrypt_password(agent.secret)
                except Exception:
                    raw_secret = agent.secret
                
                headers = {"X-Agent-Secret": raw_secret}
                url = agent.endpoint
                if ":" not in url.replace("http://", "").replace("https://", ""):
                    url = f"{url.rstrip('/')}:8005"
                
                # We use the generic /metrics endpoint which the SystemDriver implements
                response = requests.get(f"{url}/metrics", headers=headers, timeout=10)
                
                if response.status_code == 200:
                    data = response.json()
                    agent.status = "healthy"
                    agent.last_heard = datetime.now(timezone.utc)
                    
                    # Update Server telemetry
                    servers = db.query(Server).filter(Server.itam_id == agent.itam_id).all()
                    for server in servers:
                        host_data = data.get("host", {})
                        server.cpu_usage = host_data.get("cpu_usage", "0%")
                        server.mem_usage = host_data.get("mem_usage", "0MB / 0MB")
                        server.status = "Online"
                        server.last_heard = datetime.now(timezone.utc)
                    
                    infra_logger.info(f"🖥️ Updated Infra metrics for agent: {agent.agent_id}")
                else:
                    agent.status = "down"
                    infra_logger.warning(f"⚠️ Infra agent {agent.agent_id} returned {response.status_code}")
                
            except Exception as e:
                agent.status = "down"
                infra_logger.error(f"❌ Error polling infra agent {agent.agent_id}: {str(e)}")
        
        db.commit()
    finally:
        db.close()

def init_agent_engine():
    """Initializes and starts the background Dashboard Agent Engine."""
    if not scheduler.running:
        scheduler.add_job(
            fetch_podman_metrics,
            trigger=IntervalTrigger(minutes=settings.AGENT_PODMAN_INTERVAL_MINS),
            id="podman_metrics_pull",
            name="Dynamic Podman Agent Polling",
            replace_existing=True
        )
        
        scheduler.add_job(
            fetch_k8s_metrics,
            trigger=IntervalTrigger(minutes=settings.AGENT_K8S_INTERVAL_MINS),
            id="k8s_metrics_pull",
            name="Dynamic K8s Agent Polling",
            replace_existing=True
        )

        scheduler.add_job(
            fetch_infra_metrics,
            trigger=IntervalTrigger(minutes=2), # Default 2 mins for infra
            id="infra_metrics_pull",
            name="Dynamic Infra Agent Polling",
            replace_existing=True
        )
        
        scheduler.start()
        podman_logger.info("🚀 Dashboard Agent Engine Started")

def shutdown_agent_engine():
    """Gracefully shuts down the background scheduler."""
    if scheduler.running:
        scheduler.shutdown(wait=True)
        podman_logger.info("🛑 Dashboard Agent Engine Shutdown")

def get_job_status():
    """Returns the status of all registered background jobs."""
    jobs = []
    for job in scheduler.get_jobs():
        jobs.append({
            "id": job.id,
            "name": job.name,
            "next_run": job.next_run_time.isoformat() if job.next_run_time else None,
            "status": "active" if job.next_run_time else "paused"
        })
    return jobs
