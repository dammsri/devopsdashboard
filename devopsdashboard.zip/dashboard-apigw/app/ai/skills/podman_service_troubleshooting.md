# 🛠️ Skill: Podman Service Troubleshooting SOP

When a containerized service managed by Podman is reported as failing or unreachable, follow this systematic diagnostic workflow:

### 🔍 Phase 1: Lifecycle & Status
1.  **State Inspection**: Use `get_podman_diagnostics` to check if the container is `exited`, `restarting`, or `paused`.
2.  **Exit Code Analysis**: Identify the last exit code.
    *   `137`: Likely OOM (Out of Memory).
    *   `1`: General application error.
    *   `127`: Command or binary not found.

### 📋 Phase 2: Resource & Storage Audit
1.  **Disk Pressure**: Check host storage. Podman can fail to start containers if the `tmpfs` or storage volume is 100% full.
2.  **Permission Audit**: Verify if the container is running in rootless mode and if it has the necessary volume mount permissions.

### 🪵 Phase 3: Log & Network Forensic
1.  **Application Logs**: Fetch the last 100 lines of container logs. Search for database connection strings or bind-address failures.
2.  **Port Mapping**: Verify if the host port is already in use by another process (`netstat` / `ss` logic).

### ⚡ Phase 4: Remediation Actions
- **Quick Recovery**: Use `manage_system_service` or direct podman tools to **Restart** the container.
- **Cleanup**: If images are corrupted or disk is full, suggest a `podman system prune` (with caution).
- **Network Reset**: Suggest restarting the `podman.socket` or the bridge network if connectivity is lost.

---
**Constraint**: Always verify the `user` context (Root vs Rootless) before suggesting host-level configuration changes.
