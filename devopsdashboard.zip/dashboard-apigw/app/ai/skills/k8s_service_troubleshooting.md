# 🛠️ Skill: Kubernetes Service Troubleshooting SOP

When a Kubernetes service is reported as unstable, failing, or exhibiting high latency, follow this systematic diagnostic and remediation workflow:

### 🔍 Phase 1: Connectivity & Alignment
1.  **Endpoint Validation**: Verify if the Service has active Endpoints. If `endpoints` are empty, the selector likely doesn't match the pod labels.
2.  **DNS Check**: Use `get_k8s_diagnostics` to verify if the internal service name is resolvable within the namespace.

### 📋 Phase 2: Pod Health Deep-Dive
1.  **Status Inspection**: Check for `CrashLoopBackOff`, `Pending`, or `ImagePullBackOff`.
2.  **Resource Audit**: Check for `OOMKilled` events. If detected, suggest increasing memory limits.
3.  **Liveness/Readiness Failures**: Check events for "Unhealthy" probes. If readiness fails, the pod will be removed from endpoints.

### 🪵 Phase 3: Log Analysis
1.  **Error Search**: Fetch the last 100 lines of logs using `get_k8s_diagnostics`. Look for:
    *   Database connection timeouts.
    *   Permission denied (RBAC issues).
    *   Upstream API 5xx errors.

### ⚡ Phase 4: Remediation Actions
- **Transient Fix**: If the pod is stuck, use `execute_operational_action` to **Restart** (delete) the pod.
- **Resource Fix**: If CPU/RAM is throttled, suggest a **Scale** operation.
- **Configuration Fix**: If secret/configmap is missing, identify the missing resource for the user.

---
**Constraint**: Do not attempt to delete namespaces or cluster-wide resources without explicit confirmation.
