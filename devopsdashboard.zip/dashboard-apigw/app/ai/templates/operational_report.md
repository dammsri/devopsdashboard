# Operational Health Report
Date: {date}
Target: {target}

## 📊 Executive Summary
{summary}

## 🛡️ Infrastructure Status
| Component | Status | Details |
| :--- | :--- | :--- |
{infrastructure_rows}

## 🔍 Diagnostics Analysis
### Logs & Events
{diagnostics_context}

### Identified Issues
{issues_list}

## 🚀 Recommended Next Best Actions
{recommendations}
