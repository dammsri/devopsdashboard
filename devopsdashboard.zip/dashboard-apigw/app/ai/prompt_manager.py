import os
import logging
from typing import List, Optional
from app.core.config import settings

logger = logging.getLogger(__name__)

class PromptManager:
    """
    Manages the loading and assembly of modular AI prompt fragments.
    Supports specialized persona-based assembly and variable injection.
    """
    
    def __init__(self, prompts_dir: str = None):
        if prompts_dir is None:
            # Default to /app/ai/prompts/ relative to this file
            base_dir = os.path.dirname(os.path.abspath(__file__))
            self.prompts_dir = os.path.join(base_dir, "prompts")
        else:
            self.prompts_dir = prompts_dir
            
        self.variables = {
            "organization_name": settings.ORGANIZATION_NAME,
            "ai_provider": settings.AI_PROVIDER,
            "ai_model": settings.OLLAMA_CHAT_MODEL if settings.AI_PROVIDER.lower() == "ollama" 
                        else settings.OPENAI_MODEL if settings.AI_PROVIDER.lower() == "openai"
                        else settings.GEMINI_CHAT_MODEL
        }

    def _load_fragment(self, filename: str, folder: str = "prompts") -> str:
        """Loads a specific markdown fragment from the specified folder."""
        path = os.path.join(self.prompts_dir if folder == "prompts" else os.path.join(os.path.dirname(self.prompts_dir), folder), filename)
        if not os.path.exists(path):
            logger.warning(f"AI fragment not found: {path}")
            return ""
        
        try:
            with open(path, "r") as f:
                content = f.read()
                # Inject variables using .format() - note: escapes {{ }} in markdown if needed
                return content.format(**self.variables)
        except Exception as e:
            logger.error(f"Failed to load AI fragment {filename}: {e}")
            return ""

    def get_system_prompt(self, persona: Optional[str] = None) -> str:
        """
        Assembles a tailored system prompt for a specific specialist.
        """
        fragments = []
        
        # 1. Base Identity
        fragments.append(self._load_fragment("base_identity.md"))
        
        # 2. Specialized Personnel Instructions & Skills
        if persona == "k8s":
            fragments.append(self._load_fragment("k8s_expert.md"))
            fragments.append("### 📚 SPECIALIZED SKILLS")
            fragments.append(self._load_fragment("k8s_service_troubleshooting.md", folder="skills"))
        elif persona == "infra":
            fragments.append(self._load_fragment("infra_expert.md"))
            fragments.append("### 📚 SPECIALIZED SKILLS")
            fragments.append(self._load_fragment("podman_service_troubleshooting.md", folder="skills"))
        elif persona == "auditor":
            fragments.append(self._load_fragment("auditor.md"))
        else:
            # Lean generalist fallback to keep context window clean for local models
            fragments.append(self._load_fragment("k8s_expert.md"))
            fragments.append(self._load_fragment("infra_expert.md"))
            fragments.append("### 📚 GENERAL SKILLS")
            fragments.append("You are a high-level orchestrator. Use tools to fetch data only when technical details are requested.")
        
        # 3. Structural Standards
        fragments.append(self._load_fragment("formatting_guidelines.md"))
        
        return "\n\n".join([f for f in fragments if f])

# Global instance
prompt_manager = PromptManager()
