from sqlalchemy.orm import Session
from app.db.session import Base, engine
from app.models.user import User, Role, Functionality, AuthSource
from app.core.security import get_password_hash
import logging

logger = logging.getLogger(__name__)

def init_db(db: Session) -> None:
    """Initialize DB schema and seed default security data."""
    # Ensure tables are created for all models
    from app.models import application, infrastructure, k8s, user, audit, dashboard_agent # noqa
    Base.metadata.create_all(bind=engine)

    # 1. Seed Functionalities (Permissions)
    resource_categories = [
        ("infra.app", "Applications"),
        ("infra.env", "Infrastructure Environments"),
        ("infra.server", "Infrastructure Servers"),
        ("infra.service", "Generic Services"),
        ("k8s.cluster", "Kubernetes Clusters"),
        ("k8s.env", "Kubernetes Environments"),
        ("k8s.service", "Kubernetes Services"),
        ("sys.agents", "Dashboard Agents"),
        ("sys.ai", "AI Copilot & Insights"),
        ("sys.security", "Security & RBAC"),
        ("sys.user", "User Management"),
    ]

    permissions = []
    for prefix, label in resource_categories:
        permissions.extend([
            (f"{prefix}.view", f"View {label}"),
            (f"{prefix}.create", f"Create {label}"),
            (f"{prefix}.update", f"Update {label}"),
            (f"{prefix}.delete", f"Delete {label}"),
            (f"{prefix}.manage", f"Manage {label} (Full Access)"),
        ])
    
    # Add special permissions
    permissions.extend([
        ("sys.import.execute", "Execute Data Imports"),
        ("ai.chat", "AI: Access Copilot Chat"),
        ("ai.diagnose", "AI: Access Diagnostic Tools"),
        ("ai.remediate", "AI: Execute Automated Remediation"),
        ("ai.report", "AI: Generate Operational Reports")
    ])
    
    for name, desc in permissions:
        func = db.query(Functionality).filter(Functionality.name == name).first()
        if not func:
            db.add(Functionality(name=name, description=desc))
    
    db.commit()

    # 2. Seed Default Roles
    roles_to_seed = [
        ("Super Admin", "Full platform control", None),
        ("Developer", "Manage environments and services", "CN=DevOps_Developers,OU=Groups,DC=example,DC=com"),
        ("Viewer", "Read-only access", "CN=DevOps_Viewers,OU=Groups,DC=example,DC=com"),
    ]

    for name, desc, ad_group in roles_to_seed:
        role = db.query(Role).filter(Role.name == name).first()
        if not role:
            new_role = Role(name=name, description=desc, ad_group_mapping=ad_group)
            db.add(new_role)
    
    db.commit()

    # 3. Assign All Permissions to Super Admin
    super_admin_role = db.query(Role).filter(Role.name == "Super Admin").first()
    if super_admin_role:
        all_funcs = db.query(Functionality).all()
        super_admin_role.functionalities = all_funcs
        db.commit()

    # 4. Seed/Update Local Admin User
    admin = db.query(User).filter(User.user_id == "admin").first()
    if not admin:
        admin = User(
            user_id="admin",
            email="admin@devopsdashboard.io",
            first_name="Platform",
            last_name="Admin",
            hashed_password=get_password_hash("Admin@123"),
            auth_source=AuthSource.local,
            is_active=True,
        )
        db.add(admin)
        db.commit()
        logger.info("✨ Created default local admin user")
    
    # 5. Link Admin User to Super Admin Role
    if super_admin_role and super_admin_role not in admin.roles:
        admin.roles.append(super_admin_role)
        db.commit()
        logger.info("🔐 Assigned Super Admin role to admin user")

    logger.info("✅ Database initialization and security seeding complete.")
