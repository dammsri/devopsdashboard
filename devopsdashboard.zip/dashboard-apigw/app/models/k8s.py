from sqlalchemy import Column, Integer, String, ForeignKey, ForeignKeyConstraint, DateTime, JSON
from datetime import datetime, timezone
from sqlalchemy.orm import relationship
from app.db.session import Base
from app.models.application import Application

class K8sNamespace(Base):
    __tablename__ = "k8s_namespaces"

    itam_id = Column(Integer, ForeignKey("applications.itam_id", ondelete="CASCADE"), primary_key=True)
    cluster_id = Column(String, primary_key=True)
    k8s_env_id = Column(String, primary_key=True)
    namespace = Column(String, primary_key=True)
    
    description = Column(String, nullable=True)
    owner = Column(String, nullable=True)

    __table_args__ = (
        ForeignKeyConstraint(
            ["itam_id", "cluster_id", "k8s_env_id"],
            ["k8s_environments.itam_id", "k8s_environments.cluster_id", "k8s_environments.k8s_env_id"],
            ondelete="CASCADE"
        ),
    )

    application = relationship("Application", back_populates="k8s_namespaces", overlaps="cluster,environments,k8s_clusters,k8s_namespaces")
    environments = relationship("K8sEnvironment", back_populates="namespaces", overlaps="k8s_namespaces")
    services = relationship("K8sService", back_populates="namespace_reg", cascade="all, delete-orphan", overlaps="environment,services,k8s_services")

class K8sCluster(Base):
    __tablename__ = "k8s_clusters"

    itam_id = Column(Integer, ForeignKey("applications.itam_id", ondelete="CASCADE"), primary_key=True)
    cluster_id = Column(String, primary_key=True)
    cluster_name = Column(String, nullable=True)
    auth_url = Column(String, nullable=True)
    username = Column(String, nullable=True)
    password = Column(String, nullable=True) # Encrypted

    application = relationship("Application", back_populates="k8s_clusters")
    environments = relationship("K8sEnvironment", back_populates="cluster", cascade="all, delete-orphan")

class K8sEnvironment(Base):
    __tablename__ = "k8s_environments"

    itam_id = Column(Integer, ForeignKey("applications.itam_id", ondelete="CASCADE"), primary_key=True)
    cluster_id = Column(String, primary_key=True)
    k8s_env_id = Column(String, primary_key=True)
    
    name = Column(String, nullable=False)
    status = Column(String, nullable=True)
    
    # New columns
    usage = Column(String, nullable=True)
    owner = Column(String, nullable=True)
    interface_connectivity = Column(String, nullable=True)

    __table_args__ = (
        ForeignKeyConstraint(
            ["itam_id", "cluster_id"],
            ["k8s_clusters.itam_id", "k8s_clusters.cluster_id"],
            ondelete="CASCADE"
        ),
    )

    cluster = relationship("K8sCluster", back_populates="environments")
    services = relationship("K8sService", back_populates="environment", cascade="all, delete-orphan", overlaps="namespace_reg,services,k8s_services")
    namespaces = relationship("K8sNamespace", back_populates="environments", cascade="all, delete-orphan", overlaps="application,k8s_namespaces")
    application = relationship("Application", overlaps="cluster,environments") # Optional: can be navigated via cluster

class K8sService(Base):
    __tablename__ = "k8s_services"

    itam_id = Column(Integer, ForeignKey("applications.itam_id", ondelete="CASCADE"), primary_key=True)
    cluster_id = Column(String, primary_key=True)
    k8s_env_id = Column(String, primary_key=True)
    namespace = Column(String, primary_key=True)
    service_id = Column(String, primary_key=True)

    name = Column(String, nullable=False)
    replicas = Column(Integer, nullable=True)
    version = Column(String, nullable=True)
    status = Column(String, nullable=True)

    # Telemetry / Deployment Persistence
    current_image = Column(String, nullable=True)
    base_image_version = Column(String, nullable=True)
    last_version_deployed = Column(String, nullable=True)
    last_deployed_at = Column(DateTime(timezone=True), nullable=True)
    last_deployed_by = Column(String, nullable=True)
    health_status = Column(String, nullable=True) # running, failed, pending
    telemetry_metadata = Column(JSON, nullable=True)

    __table_args__ = (
        ForeignKeyConstraint(
            ["itam_id", "cluster_id", "k8s_env_id"],
            ["k8s_environments.itam_id", "k8s_environments.cluster_id", "k8s_environments.k8s_env_id"],
            ondelete="CASCADE"
        ),
        ForeignKeyConstraint(
            ["itam_id", "cluster_id", "k8s_env_id", "namespace"],
            ["k8s_namespaces.itam_id", "k8s_namespaces.cluster_id", "k8s_namespaces.k8s_env_id", "k8s_namespaces.namespace"],
            ondelete="CASCADE"
        ),
    )
    
    environment = relationship("K8sEnvironment", back_populates="services", overlaps="services,k8s_services")
    namespace_reg = relationship("K8sNamespace", back_populates="services", overlaps="environment,services,k8s_services")
    application = relationship("Application", back_populates="k8s_services", overlaps="environment,namespace_reg,services,k8s_services")
