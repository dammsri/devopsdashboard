from sqlalchemy import Column, Integer, String
from sqlalchemy.orm import relationship
from app.db.session import Base

class Application(Base):
    __tablename__ = "applications"

    itam_id = Column(Integer, primary_key=True, autoincrement=False)
    name = Column(String, nullable=False)
    description = Column(String, nullable=True)

    # Infrastructure Relationships
    environments = relationship("Environment", back_populates="application", cascade="all, delete-orphan")
    services = relationship("Service", back_populates="application", cascade="all, delete-orphan", overlaps="environment,services")
    servers = relationship("Server", back_populates="application", cascade="all, delete-orphan")

    # K8s Relationships
    k8s_clusters = relationship("K8sCluster", back_populates="application", cascade="all, delete-orphan")
    k8s_namespaces = relationship("K8sNamespace", back_populates="application", cascade="all, delete-orphan")
    k8s_services = relationship("K8sService", back_populates="application", cascade="all, delete-orphan")

    # Ops Relationships
    dashboard_agents = relationship("DashboardAgent", back_populates="application", cascade="all, delete-orphan")
