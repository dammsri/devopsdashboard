from sqlalchemy import Column, Integer, String, ForeignKey, DateTime
from datetime import datetime, timezone
from sqlalchemy.orm import relationship
from app.db.session import Base

class DashboardAgent(Base):
    __tablename__ = "dashboard_agents"

    id = Column(Integer, primary_key=True, index=True)
    agent_id = Column(String, unique=True, index=True, nullable=False) # e.g. AGENT-001
    name = Column(String, nullable=False)
    type = Column(String, nullable=False) # K8S, PODMAN
    endpoint = Column(String, nullable=False) # URL of the agent
    secret = Column(String, nullable=False) # Auth secret
    
    itam_id = Column(Integer, ForeignKey("applications.itam_id", ondelete="CASCADE"), nullable=False)
    
    status = Column(String, default="unknown") # healthy, warning, down
    last_heard = Column(DateTime(timezone=True), nullable=True)
    description = Column(String, nullable=True)
    
    # Relationship to Application
    application = relationship("Application", back_populates="dashboard_agents")
