import sys
import os

# Add current directory to path so we can import app modules
sys.path.append(os.getcwd())

# Mock settings if needed, or rely on environment
from app.ai.prompt_manager import prompt_manager

print("--- TESTING MODULAR PROMPT ASSEMBLY ---")
prompt = prompt_manager.get_system_prompt()

if "DevOps Copilot" in prompt:
    print("✅ Base Identity Loaded")
if "KUBERNETES EXPERT" in prompt:
    print("✅ K8s Persona Loaded")
if "INFRA EXPERT" in prompt:
    print("✅ Infra Persona Loaded")
if "Formatting Guidelines" in prompt:
    print("✅ Formatting Guidelines Loaded")

print("\n--- ASSEMBLED PROMPT PREVIEW ---")
print(prompt[:500] + "...")
