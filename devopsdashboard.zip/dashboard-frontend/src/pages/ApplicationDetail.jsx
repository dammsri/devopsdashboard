import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { applicationsApi } from "../api/services";
import { RiAppsLine, RiArrowRightSLine, RiGlobeLine } from "react-icons/ri";
import HexagonCard from "../components/ui/HexagonCard";

export default function ApplicationDetail() {
  const { appId } = useParams();
  const [app, setApp] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    applicationsApi.getApplications()
      .then(res => {
        const found = res.data.find(a => String(a.itam_id) === String(appId));
        setApp(found || null);
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, [appId]);

  if (loading) return <div className="p-8 text-slate-500 animate-pulse">Loading application...</div>;
  if (!app) return <div className="p-8 text-red-500">Application not found.</div>;

  return (
    <div className="space-y-8 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col gap-2 border-b border-slate-200 dark:border-slate-800 pb-4">
        <div className="flex items-center gap-2 text-sm text-slate-500 mb-1">
          <Link to="/dashboard/applications" className="hover:text-brand-600 transition-colors">Applications</Link>
          <RiArrowRightSLine />
          <span className="font-medium text-slate-900 dark:text-white">{app.name}</span>
        </div>
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-bold text-slate-900 dark:text-white flex items-center gap-3">
            <RiAppsLine className="text-brand-500" /> {app.name}
          </h1>
          <span className="text-sm text-slate-500 dark:text-slate-400 bg-slate-100 dark:bg-slate-800 px-3 py-1.5 rounded-xl font-medium">
            {app.environments?.length || 0} Environment{(app.environments?.length || 0) !== 1 ? 's' : ''}
          </span>
        </div>
        <p className="text-slate-500 dark:text-slate-400">
          {app.description || "Select an environment to view infrastructure servers, deployed components, and recent deployment history."}
        </p>
      </div>

      {/* Environments View - Standardized to Honeycomb */}
      <div className="honeycomb-container py-8">
        <div className="honeycomb-grid">
          {Array.from({ length: Math.ceil((app.environments?.length || 0) / 4) }).map((_, rowIndex) => {
            const rowEnvs = (app.environments || []).slice(rowIndex * 4, (rowIndex + 1) * 4);
            return (
              <div key={rowIndex} className="honeycomb-row">
                {rowEnvs.map((env) => (
                  <HexagonCard
                    key={env.env_id}
                    title={env.name}
                    status={env.status}
                    icon={RiGlobeLine}
                    to={`/dashboard/applications/${app.itam_id}/environments/${env.env_id}`}
                  />
                ))}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
