import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { k8sEnvironmentsApi } from "../api/services";
import { RiRocketLine, RiArrowRightSLine } from "react-icons/ri";
import { SiKubernetes } from "react-icons/si";
import HexagonCard from "../components/ui/HexagonCard";

export default function K8sEnvironmentServiceGrid() {
  const { k8sEnvId } = useParams();
  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    k8sEnvironmentsApi.getEnvironmentServices(k8sEnvId)
      .then(res => setServices(res.data))
      .catch(console.error)
      .finally(() => setLoading(false));
  }, [k8sEnvId]);

  if (loading) return <div className="p-8 text-slate-500 animate-pulse">Loading {k8sEnvId} services...</div>;

  return (
    <div className="space-y-8 animate-fade-in">
      <div className="flex flex-col gap-2 border-b border-slate-200 dark:border-slate-800 pb-4">
        <div className="flex items-center gap-2 text-sm text-slate-500 mb-1">
          <Link to="/dashboard/k8s-environments" className="hover:text-brand-600 transition-colors">K8s Environments</Link>
          <RiArrowRightSLine />
          <span className="uppercase">{k8sEnvId}</span>
        </div>
        <h1 className="text-3xl font-bold text-slate-900 dark:text-white flex items-center gap-3">
          <SiKubernetes className="text-brand-500" /> Environment {k8sEnvId.toUpperCase()}
        </h1>
        <p className="text-slate-500 dark:text-slate-400">
          Service mesh overview. Select a service to view health metrics, replicas, and pod logs.
        </p>
      </div>

      <div className="honeycomb-container py-10">
        <div className="honeycomb-grid">
          {Array.from({ length: Math.ceil((services?.length || 0) / 4) }).map((_, rowIndex) => {
            const rowServices = (services || []).slice(rowIndex * 4, (rowIndex + 1) * 4);
            return (
              <div key={rowIndex} className="honeycomb-row">
                {rowServices.map((svc) => (
                  <HexagonCard
                    key={svc.service_id}
                    title={svc.name}
                    subtitle={svc.version}
                    status={svc.status}
                    icon={RiRocketLine}
                    to={`/dashboard/k8s-environments/${k8sEnvId}/services/${svc.service_id}`}
                  />
                ))}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
