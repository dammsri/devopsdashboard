import React, { useState, useRef, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  RiRobot2Line, RiSendPlane2Fill, RiRobotLine, 
  RiHammerLine, RiCheckDoubleLine, RiFlashlightLine,
  RiInformationLine, RiPulseLine, RiServerLine, RiAppsLine, RiMagicLine,
  RiHistoryLine, RiCloseLine
} from 'react-icons/ri';
import { SiKubernetes } from "react-icons/si";

import { useAIStore } from '../store/aiStore';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import AIRichResponse from '../components/ai/AIRichResponse';
import { dashboardApi } from '../api/services';

const MessageBubble = ({ message, isLast, thinkingTime }) => {
  const isAi = ['assistant', 'ai', 'bot', 'model'].includes(message.role?.toLowerCase());
  const isUser = ['user', 'human'].includes(message.role?.toLowerCase());
  const { executeAction } = useAIStore();
  const [isExecuting, setIsExecuting] = useState(false);
  const [isDone, setIsDone] = useState(false);

  // Suggested action parsing
  let suggestedAction = null;
  if (isAi && message.content && message.content.includes('"type": "SUGGESTED_ACTION"')) {
    try {
      const parts = message.content.split('Please confirm: ');
      if (parts.length > 1) {
        suggestedAction = JSON.parse(parts[1]);
      }
    } catch (e) {
      console.error("Failed to parse suggested action", e);
    }
  }

  const handleConfirmAction = async () => {
    if (!suggestedAction) return;
    setIsExecuting(true);
    try {
      await executeAction(suggestedAction.action, suggestedAction.rationale, suggestedAction.payload);
      setIsDone(true);
    } catch (e) {
      console.error("Action execution failed", e);
    } finally {
      setIsExecuting(false);
    }
  };

  // Clickable suggested queries parsing
  const { sendMessage: sendQuery } = useAIStore();
  const suggestedQueries = useMemo(() => {
    if (!message.content) return [];
    const regex = /\[\[(?:SUGGESTED_QUERY:\s*)?"?([^"\]]+)"?\s*\]\]/g;
    const queries = [];
    let match;
    while ((match = regex.exec(message.content)) !== null) {
      queries.push(match[1]);
    }
    return queries;
  }, [message.content]);

  const cleanContent = useMemo(() => {
    if (!message.content) return message.content;
    return message.content
      .replace(/\[\[(?:SUGGESTED_QUERY:\s*)?"?([^"\]]+)"?\s*\]\]/g, '')
      .replace(/"type": "SUGGESTED_ACTION".*$/, '')
      .trim();
  }, [message.content]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className={`flex flex-col mb-10 w-full max-w-[1400px] mx-auto ${isAi ? 'items-start' : 'items-end'}`}
    >
      <div className={`flex items-start gap-4 w-full ${isAi ? 'flex-row' : 'flex-row-reverse'}`}>
         {isAi && (
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-brand-600 to-accent-500 flex items-center justify-center text-white shadow-lg shadow-brand-500/20 flex-shrink-0 mt-1">
              <RiRobot2Line size={24} />
            </div>
         )}
         
         <div className={`flex-1 min-w-0 ${isAi ? '' : 'flex flex-col items-end'}`}>
            <div className={`px-6 ${isAi ? 'py-3' : 'py-2.5'} rounded-[2rem] text-sm leading-relaxed ${isAi
                    ? 'bg-white dark:bg-slate-900 border border-slate-200/60 dark:border-slate-800 shadow-sm w-fit max-w-[70%]'
                    : 'bg-brand-600 text-white rounded-tr-none shadow-xl shadow-brand-500/20 inline-block max-w-[80%]'
                }`}
            >
                {isAi && isLast && !message.content ? (
                    <div className="flex items-center gap-3 py-1">
                        <div className="flex gap-1.5">
                            <div className="w-1.5 h-1.5 bg-brand-400 rounded-full animate-bounce [animation-delay:-0.3s]"></div>
                            <div className="w-1.5 h-1.5 bg-brand-400 rounded-full animate-bounce [animation-delay:-0.15s]"></div>
                            <div className="w-1.5 h-1.5 bg-brand-400 rounded-full animate-bounce"></div>
                        </div>
                        {thinkingTime > 0 && (
                            <span className="text-[10px] font-bold text-slate-400 tracking-widest animate-pulse ml-2">
                                Thinking... {thinkingTime.toFixed(1)}s
                            </span>
                        )}
                    </div>
                ) : (
                    isAi ? (
                      <AIRichResponse 
                        content={cleanContent} 
                        isStreaming={isLast && !message.totalTime}
                      />
                    ) : (
                      <div className="whitespace-pre-wrap font-medium">{message.content}</div>
                    )
                )}

                    {isAi && suggestedQueries.length > 0 && (
                      <div className="mt-6 flex flex-wrap gap-2 pt-4 border-t border-slate-100 dark:border-slate-800">
                        {suggestedQueries.map((q, i) => (
                          <button
                            key={i}
                            onClick={() => sendQuery(q)}
                            className="px-4 py-2 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 text-xs font-bold text-brand-600 dark:text-brand-400 hover:bg-brand-500 hover:text-white dark:hover:bg-brand-600 transition-all active:scale-95"
                          >
                            {q}
                          </button>
                        ))}
                      </div>
                    )}

                    {suggestedAction && (
                    <div className="mt-6 p-5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-brand-500/30 backdrop-blur-sm">
                        <div className="flex items-center gap-2 text-brand-600 dark:text-brand-400 font-black text-[10px] uppercase tracking-widest mb-3">
                        <RiHammerLine size={16} />
                        Proposed Action
                        </div>
                        <div className="text-sm font-bold text-slate-800 dark:text-white mb-2">
                        {suggestedAction.action}: {suggestedAction.target}
                        </div>
                        <p className="text-xs text-slate-500 dark:text-slate-400 mb-4 italic leading-relaxed">
                        Rationale: {suggestedAction.rationale}
                        </p>
                        <button
                        onClick={handleConfirmAction}
                        disabled={isExecuting || isDone}
                        className={`w-full py-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 ${isDone
                            ? 'bg-accent-500 text-white cursor-default'
                            : 'bg-brand-600 hover:bg-brand-700 text-white shadow-lg shadow-brand-500/30'
                            }`}
                        >
                        {isExecuting ? 'Executing...' : isDone ? <><RiCheckDoubleLine /> Done</> : 'Confirm Action'}
                        </button>
                    </div>
                    )}
            </div>

            {isAi && message.totalTime > 0 && (
                <div className="mt-2 px-1 flex items-center gap-2 animate-fade-in">
                    <span 
                        className="text-[10px] font-bold text-slate-400 dark:text-slate-500 tracking-wider"
                        style={{ textTransform: 'none' }}
                    >
                        Response in {message.totalTime.toFixed(1)}s
                    </span>
                </div>
            )}
         </div>
      </div>
    </motion.div>
  );
};

export default function DashboardHome() {
  const { user } = useAuth();
  const { 
    messages, 
    isLoading, 
    thinkingTime, 
    sendMessage,
    conversations,
    currentConversationId,
    loadConversations,
    loadConversation,
    startNewChat,
    deleteConversation
  } = useAIStore();

  const [inputValue, setInputValue] = useState('');
  const [showHistory, setShowHistory] = useState(false);
  const messagesEndRef = useRef(null);
  const containerRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, thinkingTime]);

  const { isAuthenticated, loading: authLoading } = useAuth();
  const [systemStats, setSystemStats] = useState(null);

  useEffect(() => {
    const fetchQuickStats = async () => {
        if (!isAuthenticated) return;
        try {
            const { data } = await dashboardApi.getStats();
            setSystemStats(data);
        } catch (e) {
            console.error("Failed to load suggestions stats", e);
        }
    };
    
    if (isAuthenticated) {
        fetchQuickStats();
        loadConversations();
    }
  }, [isAuthenticated]);

  const dynamicSuggestions = useMemo(() => {
    // 1. Check for AI Follow-ups FIRST
    const lastMsg = messages.length > 0 ? messages[messages.length - 1] : null;
    if (lastMsg && lastMsg.role === 'ai' && lastMsg.content) {
        const suggestionRegex = /\[\[(?:SUGGESTED_QUERY:\s*)?"?([^"\]]+)"?\s*\]\]/g;
        const conversationSuggs = [];
        let match;
        while ((match = suggestionRegex.exec(lastMsg.content)) !== null) {
            conversationSuggs.push({
                icon: RiMagicLine,
                label: match[1],
                query: match[1],
                color: "text-indigo-500"
            });
        }
        if (conversationSuggs.length > 0) return conversationSuggs.slice(0, 5);
    }

    // 2. Fallback to System Starters
    const s = [];
    const defaults = [
        { icon: RiPulseLine, label: systemStats ? "Platform Health" : "Syncing Health...", query: "Show me a health summary of the entire ecosystem", color: "text-brand-500" },
        { icon: RiAppsLine, label: systemStats ? "App Summary" : "Syncing Apps...", query: "List all applications and their health status", color: "text-indigo-500" },
        { icon: SiKubernetes, label: systemStats ? "K8s Clusters" : "Syncing Clusters...", query: "Show me all Kubernetes clusters and active namespaces", color: "text-teal-500" },
        { icon: RiServerLine, label: systemStats ? "Infra Audit" : "Syncing Infra...", query: "Give me a summary of all infrastructure and server distribution", color: "text-amber-500" },
        { icon: RiInformationLine, label: "AI Capabilities", query: "What can you do for me as a DevOps Copilot?", color: "text-accent-500" }
    ];

    if (!systemStats) return defaults;

    const { total_applications, total_servers, total_environments, success_rate } = systemStats;

    if (success_rate < 95) {
        s.push({ icon: RiPulseLine, label: `Review Health (${success_rate}%)`, query: "Analyze why the platform success rate is below 95%", color: "text-rose-500" });
    } else {
        s.push({ icon: RiCheckDoubleLine, label: "System Health", query: "Show me all unhealthy servers and clusters", color: "text-emerald-500" });
    }

    s.push({ icon: RiAppsLine, label: `Audit ${total_applications} Apps`, query: "Give me a summary table of all applications and their ITAM IDs", color: "text-indigo-500" });
    s.push({ icon: RiServerLine, label: `Infra (${total_servers} Serv)`, query: `List all ${total_servers} servers across ${total_environments} environments`, color: "text-amber-500" });
    s.push({ icon: SiKubernetes, label: "K8s Environments", query: "Summarize status of all Kubernetes namespaces and environments", color: "text-teal-500" });
    s.push({ icon: RiPulseLine, label: "Ops Audit", query: "Show me all recent automated jobs and their status", color: "text-brand-500" });
    
    return s.slice(0, 5);
  }, [systemStats, messages]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!inputValue.trim() || isLoading) return;
    sendMessage(inputValue);
    setInputValue('');
  };

  const handleSelectConversation = (id) => {
    loadConversation(id);
    setShowHistory(false);
  };

  const handleNewChat = () => {
    startNewChat();
    setShowHistory(false);
  };

  return (
    <div className="flex flex-col h-full bg-slate-50 dark:bg-slate-950">
      {/* Scrollable Chat Area */}
      <div className="flex-1 overflow-y-auto px-6 py-10 space-y-4" ref={containerRef}>
        <div className="max-w-[1400px] mx-auto w-full">
            {/* Welcome Message */}
            <AnimatePresence>
                {messages.length === 0 && (
                    <motion.div 
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -20 }}
                        className="py-20 text-center space-y-8"
                    >
                        <div className="w-20 h-20 rounded-[2.5rem] bg-gradient-to-br from-brand-600 to-accent-500 flex items-center justify-center text-white shadow-2xl shadow-brand-500/20 mx-auto mb-6 transform rotate-3">
                            <RiRobot2Line size={48} />
                        </div>
                        <div>
                            <h1 className="text-4xl font-black text-slate-900 dark:text-white tracking-tight">
                                Welcome, <span className="text-brand-600 dark:text-brand-400">{user?.first_name || 'Champion'}</span>!
                            </h1>
                            <p className="text-slate-500 dark:text-slate-400 mt-3 text-lg font-medium max-w-2xl mx-auto">
                                I am your <span className="text-brand-600 dark:text-brand-400 font-bold">DevOps Copilot</span>. I can help you monitor health, manage infrastructure, and analyze Kubernetes environments across the ecosystem.
                            </p>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 max-w-4xl mx-auto pt-10">
                            {[
                                { 
                                  title: "Platform Health", 
                                  icon: RiPulseLine, 
                                  color: "text-brand-500", 
                                  query: "Show me a health summary of the entire ecosystem",
                                  desc: systemStats ? `Current success rate is ${systemStats.success_rate}%. Click to analyze.` : "Fetching live platform telemetry..." 
                                },
                                { 
                                  title: "Inventory Audit", 
                                  icon: RiAppsLine, 
                                  color: "text-indigo-500", 
                                  query: "List all applications and their health status",
                                  desc: systemStats ? `Audit ${systemStats.total_applications} applications across environments.` : "Syncing application inventory..." 
                                },
                                { 
                                  title: "Infrastructure", 
                                  icon: RiServerLine, 
                                  color: "text-amber-500", 
                                  query: "Give me a summary of all infrastructure and server distribution",
                                  desc: systemStats ? `Monitoring ${systemStats.total_servers} servers in ${systemStats.total_environments} regions.` : "Identifying server distribution..." 
                                }
                            ].map((item, i) => (
                                <div 
                                  key={i} 
                                  onClick={() => sendMessage(item.query)}
                                  className="glass p-6 rounded-[2rem] border border-slate-200 dark:border-slate-800 text-left hover:border-brand-500/50 transition-all group cursor-pointer active:scale-[0.98] shadow-sm hover:shadow-xl hover:shadow-brand-500/5"
                                >
                                    <div className="w-10 h-10 rounded-2xl bg-slate-50 dark:bg-slate-900 flex items-center justify-center mb-4 group-hover:bg-brand-500 group-hover:text-white transition-all duration-300">
                                        <item.icon size={20} className={`${item.color} group-hover:text-white`} />
                                    </div>
                                    <h3 className="font-bold text-slate-900 dark:text-white text-sm tracking-tight">{item.title}</h3>
                                    <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-2 leading-relaxed font-medium">{item.desc}</p>
                                </div>
                            ))}
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>

            {/* Chat Messages */}
            {messages.map((msg, idx) => (
                <MessageBubble 
                    key={idx} 
                    message={msg} 
                    isLast={idx === messages.length - 1}
                    thinkingTime={thinkingTime}
                />
            ))}
            <div ref={messagesEndRef} className="h-40" />
        </div>
      </div>

      {/* Persistent Prompt Area */}
      <div className="bg-white/80 dark:bg-slate-900/80 backdrop-blur-xl border-t border-slate-200 dark:border-slate-800 p-6 sticky bottom-0 z-[100] shadow-[0_-10px_40px_rgba(0,0,0,0.05)]">
        <div className="max-w-4xl mx-auto relative group">
            
            {/* History Popup Overlay */}
            <AnimatePresence>
                {showHistory && (
                    <motion.div
                        initial={{ opacity: 0, y: 10, scale: 0.95 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, y: 10, scale: 0.95 }}
                        className="absolute bottom-full left-0 right-0 mb-4 bg-white dark:bg-slate-800 rounded-[2rem] shadow-2xl border border-slate-200 dark:border-slate-700 overflow-hidden z-[101]"
                    >
                        <div className="p-4 border-b border-slate-100 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-900/50 flex justify-between items-center">
                            <span className="text-[10px] font-black text-slate-400 tracking-widest uppercase">Diagnostic History</span>
                            <button onClick={handleNewChat} className="text-[10px] font-black text-brand-600 hover:text-brand-700 uppercase tracking-widest">+ Start New</button>
                        </div>
                        <div className="max-h-[300px] overflow-y-auto p-2">
                            {conversations.length === 0 ? (
                                <div className="p-8 text-center text-xs text-slate-400 italic">No previous sessions found</div>
                            ) : (
                                conversations.map(conv => (
                                    <div 
                                        key={conv.id}
                                        onClick={() => handleSelectConversation(conv.id)}
                                        className={`group relative p-3 mb-1 rounded-xl cursor-pointer transition-all ${currentConversationId === conv.id 
                                            ? 'bg-brand-500/10 border border-brand-500/30' 
                                            : 'hover:bg-slate-50 dark:hover:bg-slate-700/50 border border-transparent'
                                        }`}
                                    >
                                        <div className="text-xs font-bold text-slate-700 dark:text-slate-200 truncate pr-10">{conv.title}</div>
                                        <div className="text-[10px] text-slate-400 mt-0.5">{new Date(conv.created_at).toLocaleDateString()}</div>
                                        <button 
                                            onClick={(e) => { e.stopPropagation(); deleteConversation(conv.id); }}
                                            className="absolute right-4 top-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 text-slate-300 hover:text-rose-500 transition-all"
                                        >
                                            <RiCloseLine size={18} />
                                        </button>
                                    </div>
                                ))
                            )}
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>

            <form onSubmit={handleSubmit} className="relative">
                <div className="absolute inset-y-0 left-4 flex items-center z-20 gap-2">
                    <button 
                        type="button"
                        onClick={() => setShowHistory(!showHistory)}
                        title="Toggle History"
                        className={`p-2 rounded-xl transition-all ${showHistory 
                            ? 'bg-brand-600 text-white shadow-lg' 
                            : 'text-slate-400 hover:text-brand-500 hover:bg-slate-100 dark:hover:bg-slate-800'}`}
                    >
                        <RiHistoryLine size={20} />
                    </button>
                    <div className="h-6 w-px bg-slate-200 dark:bg-slate-700 mx-1" />
                    <RiRobot2Line className={`text-xl transition-colors ${isLoading ? 'text-brand-500 animate-pulse' : 'text-slate-400 group-focus-within:text-brand-500'}`} />
                </div>
                
                <input
                    type="text"
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    placeholder={isLoading ? "Copilot is working..." : "Ask your DevOps Copilot anything..."}
                    disabled={isLoading}
                    className="w-full bg-slate-50 dark:bg-slate-800 border-2 border-slate-100 dark:border-slate-700 rounded-[2rem] pl-24 pr-32 py-5 text-sm font-medium focus:ring-4 focus:ring-brand-500/10 focus:border-brand-500 outline-none transition-all dark:text-white shadow-inner"
                />
                
                <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-2">
                    <button
                        type="button"
                        onClick={handleNewChat}
                        title="New Chat Session"
                        className="p-2.5 rounded-full bg-slate-100 dark:bg-slate-700 text-slate-500 hover:text-brand-600 transition-all"
                    >
                        <RiRobotLine size={20} />
                    </button>
                    <button
                        type="submit"
                        disabled={isLoading || !inputValue.trim()}
                        className={`p-3 rounded-full transition-all duration-300 ${
                            isLoading || !inputValue.trim()
                                ? 'bg-slate-100 dark:bg-slate-700 text-slate-300 dark:text-slate-500 cursor-not-allowed'
                                : 'bg-gradient-to-br from-brand-600 to-accent-500 text-white shadow-lg shadow-brand-500/40 hover:scale-110 active:scale-95'
                        }`}
                    >
                        <RiSendPlane2Fill size={20} />
                    </button>
                </div>
            </form>
        </div>
        <p className="text-[10px] text-center text-slate-400 mt-4 font-bold uppercase tracking-widest opacity-50">
            {import.meta.env.VITE_FOOTER_TEXT}
        </p>
      </div>
    </div>
  );
}
