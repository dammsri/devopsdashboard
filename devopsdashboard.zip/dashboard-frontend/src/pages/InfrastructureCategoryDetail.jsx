import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { infrastructureApi } from "../api/services";
import { RiAppsLine, RiArrowRightSLine, RiServerLine } from "react-icons/ri";
import HexagonCard from "../components/ui/HexagonCard";

export default function InfrastructureCategoryDetail() {
  const { category } = useParams();
  const [categoryData, setCategoryData] = useState(null);

  useEffect(() => {
    infrastructureApi.getInfrastructureGroups().then(r => {
      const match = r.data.find(g => g.id === category);
      setCategoryData(match);
    }).catch(console.error);
  }, [category]);

  if (!categoryData) return <div className="p-8 text-slate-500 animate-pulse">Loading {category} infrastructure...</div>;

  return (
    <div className="space-y-8 animate-fade-in">
      <div className="flex flex-col gap-2 border-b border-slate-200 dark:border-slate-800 pb-4">
        <div className="flex items-center gap-2 text-sm text-slate-500 mb-1">
          <Link to="/dashboard/infrastructure" className="hover:text-brand-600 transition-colors">Infrastructure</Link>
          <RiArrowRightSLine />
          <span className="capitalize">{category}</span>
        </div>
        <h1 className="text-3xl font-bold text-slate-900 dark:text-white flex items-center gap-3">
          <RiServerLine className="text-brand-500" /> {categoryData.name} Tier
        </h1>
        <p className="text-slate-500 dark:text-slate-400">
          Select an application to view dedicated server specifications and host mapping.
        </p>
      </div>

      <div className="honeycomb-container py-10">
        <div className="honeycomb-grid">
          {Array.from({ length: Math.ceil(categoryData.apps.length / 4) }).map((_, rowIndex) => {
            const rowApps = categoryData.apps.slice(rowIndex * 4, (rowIndex + 1) * 4);
            return (
              <div key={rowIndex} className="honeycomb-row">
                {rowApps.map((app) => (
                  <HexagonCard
                    key={app.id}
                    title={app.name}
                    subtitle={`${app.server_count || 0} Servers`}
                    icon={RiAppsLine}
                    to={`/dashboard/infrastructure/${category}/${app.id}`}
                  />
                ))}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
