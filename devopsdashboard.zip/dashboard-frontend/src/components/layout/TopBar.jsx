import { Fragment } from "react";
import { Link, useLocation } from "react-router-dom";
import { Menu, Transition } from "@headlessui/react";
import { motion } from "framer-motion";
import {
  RiSunLine, RiMoonLine, RiBellLine,
  RiUserLine, RiLogoutBoxLine, RiSettings3Line,
} from "react-icons/ri";
import { useAuth } from "../../context/AuthContext";
import { useTheme } from "../../context/ThemeContext";
import { usePreferences } from "../../context/PreferencesContext";

const ROLE_BADGE = {
  admin: "badge-purple",
  developer: "badge-info",
  viewer: "badge-success",
};

function useBreadcrumbs() {
  const { pathname } = useLocation();
  const parts = pathname.replace("/dashboard", "").split("/").filter(Boolean);

  if (parts.length === 0) {
    return [{ label: "Dashboard", to: "/dashboard" }];
  }

  const crumbs = [{ label: "Dashboard", to: "/dashboard" }];
  let currentPath = "/dashboard";

  parts.forEach((part) => {
    currentPath += `/${part}`;
    // Exclude ID portions from looking ugly if possible, but for now just title case everything
    // e.g. /applications/app-1/environments/env-1
    const label = part.startsWith("app-") || part.startsWith("env-")
      ? part.replace("app-", "App: ").replace("env-", "Env: ")
      : part.charAt(0).toUpperCase() + part.slice(1).replace(/-/g, " ");

    crumbs.push({ label, to: currentPath });
  });

  return crumbs;
}

export default function TopBar() {
  const { user, logout } = useAuth();
  const { isDark, toggle } = useTheme();
  const { fontScale, setFontScale } = usePreferences();
  const crumbs = useBreadcrumbs();
  
  const fontScales = [80, 90, 100, 110, 120];
  const currentIdx = fontScales.indexOf(fontScale);
  
  const handleFontIncrease = () => {
    if (currentIdx < fontScales.length - 1) setFontScale(fontScales[currentIdx + 1]);
  };
  const handleFontDecrease = () => {
    if (currentIdx > 0) setFontScale(fontScales[currentIdx - 1]);
  };
  const handleFontReset = () => setFontScale(100);

  return (
    <header className="h-16 flex items-center justify-between px-6 bg-slate-50/80 dark:bg-slate-900/80 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 z-50">
      {/* ── Brand & Logo ── */}
      <div className="flex items-center gap-3">
        <Link to="/dashboard" className="flex items-center gap-3 group transition-transform hover:scale-105 active:scale-95">
          <img 
            src="/org-logo.png" 
            alt={import.meta.env.VITE_ORGANIZATION_NAME} 
            className="h-8 w-auto object-contain drop-shadow-sm" 
          />
          <div className="flex flex-col">
            <span className="font-bold text-slate-900 dark:text-white leading-tight tracking-tight">DevOps Copilot</span>
            <span className="text-[10px] font-bold text-accent-500 uppercase tracking-widest leading-tight">Command Center</span>
          </div>
        </Link>

        <div className="h-8 w-px bg-slate-200 dark:bg-slate-800 mx-2" />

        <Link 
          to="/dashboard/settings" 
          className="flex items-center gap-2 px-3 py-1.5 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500 dark:text-slate-400 transition-all group"
          title="Global Settings"
        >
          <RiSettings3Line className="text-xl group-hover:rotate-90 transition-transform duration-500" />
          <span className="text-sm font-bold hidden md:block">Settings</span>
        </Link>
      </div>

      {/* ── Right actions ── */}
      <div className="flex items-center gap-3">
        {/* Theme toggle */}
        <motion.button
          id="theme-toggle"
          onClick={toggle}
          whileTap={{ scale: 0.9 }}
          className="w-9 h-9 rounded-xl flex items-center justify-center text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-all"
          title="Toggle theme"
        >
          {isDark
            ? <RiSunLine className="text-lg text-amber-400" />
            : <RiMoonLine className="text-lg text-brand-500" />
          }
        </motion.button>
        
        {/* Font resize controls */}
        <div className="flex items-center gap-1 bg-slate-100/50 dark:bg-slate-800/50 rounded-xl p-1">
          <button 
            onClick={handleFontDecrease}
            className="w-7 h-7 flex items-center justify-center rounded-lg text-slate-500 dark:text-slate-400 hover:bg-white dark:hover:bg-slate-700 hover:text-brand-600 transition-all text-sm font-bold active:scale-90"
            title="Decrease font size"
            disabled={currentIdx === 0}
          >
            A-
          </button>
          <button 
            onClick={handleFontReset}
            className={`w-7 h-7 flex items-center justify-center rounded-lg text-[10px] font-black tracking-widest transition-all ${fontScale === 100 ? 'bg-brand-600 text-white shadow-sm' : 'text-slate-500 dark:text-slate-400 hover:bg-white dark:hover:bg-slate-700 hover:text-brand-600'}`}
            title="Reset font size"
          >
            A
          </button>
          <button 
            onClick={handleFontIncrease}
            className="w-7 h-7 flex items-center justify-center rounded-lg text-slate-500 dark:text-slate-400 hover:bg-white dark:hover:bg-slate-700 hover:text-brand-600 transition-all text-sm font-bold active:scale-90"
            title="Increase font size"
            disabled={currentIdx === fontScales.length - 1}
          >
            A+
          </button>
        </div>

        {/* Notifications */}
        <button className="w-9 h-9 rounded-xl flex items-center justify-center text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-all relative">
          <RiBellLine className="text-lg" />
          <span className="absolute top-2 right-2 w-2 h-2 rounded-full bg-red-500 ring-2 ring-white dark:ring-slate-900" />
        </button>

        {/* User menu */}
        <Menu as="div" className="relative">
          <Menu.Button id="user-menu-btn" className="flex items-center gap-2.5 px-3 py-1.5 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-all cursor-pointer">
            {/* Avatar */}
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-brand-400 to-indigo-600 flex items-center justify-center text-white text-sm font-bold shadow-sm">
              {user?.first_name?.[0]?.toUpperCase() || "U"}
            </div>
            <div className="hidden sm:block text-left">
              <p className="text-sm font-bold text-slate-900 dark:text-white leading-tight">
                {user?.first_name || "User"}
              </p>
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest leading-tight">{user?.role}</p>
            </div>
            {user?.role && (
              <span className={`badge ${ROLE_BADGE[user.role] || "badge-info"} hidden md:inline-flex`}>
                {user.role}
              </span>
            )}
          </Menu.Button>

          <Transition
            as={Fragment}
            enter="transition ease-out duration-100" enterFrom="opacity-0 scale-95" enterTo="opacity-100 scale-100"
            leave="transition ease-in duration-75" leaveFrom="opacity-100 scale-100" leaveTo="opacity-0 scale-95"
          >
            <Menu.Items className="absolute right-0 mt-2 w-52 rounded-2xl bg-white dark:bg-slate-800 border border-slate-100 dark:border-slate-700 shadow-xl shadow-slate-200/50 dark:shadow-slate-950/50 py-2 z-50 focus:outline-none">
              {[
                { icon: RiUserLine, label: "Profile", href: "/dashboard/settings/profile" },
                { icon: RiSettings3Line, label: "Settings", href: "/dashboard/settings" },
              ].map(({ icon: Icon, label, href }) => (
                <Menu.Item key={label}>
                  {({ active }) => (
                    <Link to={href} className={`flex items-center gap-3 px-4 py-2.5 text-sm transition-colors ${active ? "bg-slate-50 dark:bg-slate-700/60 text-brand-600 dark:text-brand-400" : "text-slate-700 dark:text-slate-300"}`}>
                      <Icon className="text-base" /> {label}
                    </Link>
                  )}
                </Menu.Item>
              ))}

              <div className="my-1.5 border-t border-slate-100 dark:border-slate-700" />

              <Menu.Item>
                {({ active }) => (
                  <button
                    id="logout-btn"
                    onClick={logout}
                    className={`w-full flex items-center gap-3 px-4 py-2.5 text-sm transition-colors ${active ? "bg-red-50 dark:bg-red-900/20 text-red-600" : "text-slate-700 dark:text-slate-300"}`}
                  >
                    <RiLogoutBoxLine className="text-base" /> Sign out
                  </button>
                )}
              </Menu.Item>
            </Menu.Items>
          </Transition>
        </Menu>
      </div>
    </header>
  );
}
