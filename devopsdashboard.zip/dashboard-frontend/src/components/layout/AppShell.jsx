import { Outlet } from "react-router-dom";
import TopBar from "./TopBar";
import { ToastContainer } from "../ui/Toast";

export default function AppShell() {
  return (
    <div className="flex h-screen overflow-hidden bg-slate-100 dark:bg-slate-950">
      <ToastContainer />

      {/* Main area - Now full width since Sidebar is removed */}
      <div className="flex flex-col flex-1 min-w-0 overflow-hidden">
        <TopBar />
        <main className="flex-1 overflow-hidden animate-fade-in">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
