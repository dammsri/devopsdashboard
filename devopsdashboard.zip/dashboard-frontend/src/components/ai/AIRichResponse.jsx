import React, { useMemo, useState, useRef, useEffect } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { 
  RiFileCopyLine, RiDownload2Line, RiTableLine, 
  RiBarChartLine, RiPieChartLine, RiLineChartLine, RiSearchLine,
  RiArrowRightSLine
} from 'react-icons/ri';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell,
  PieChart, Pie, AreaChart, Area, LineChart, Line
} from 'recharts';
import { notify } from '../../store/notificationStore';

const CHART_COLORS = ['#6366f1', '#2dd4bf', '#fbbf24', '#f43f5e', '#8b5cf6', '#ec4899'];

// Helper to export data to CSV
const exportToCsv = (filename, rows) => {
  if (!rows || !rows.length) return;
  const processRow = (row) => {
    return row.map(val => {
      let cell = val === null || val === undefined ? '' : String(val);
      cell = cell.replace(/"/g, '""');
      if (cell.search(/("|,|\n)/g) >= 0) cell = `"${cell}"`;
      return cell;
    }).join(',');
  };

  const csvContent = rows.map(processRow).join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);
  link.setAttribute('href', url);
  link.setAttribute('download', `${filename}.csv`);
  link.style.visibility = 'hidden';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};

export const MarkdownTable = ({ node, children, ...props }) => {
  const [search, setSearch] = useState("");
  const tableRef = useRef(null);

  useEffect(() => {
    if (!tableRef.current) return;
    const body = tableRef.current.querySelector('tbody');
    if (!body) return;

    const rows = Array.from(body.querySelectorAll('tr'));
    const term = search.toLowerCase();

    rows.forEach(row => {
      const text = row.innerText.toLowerCase();
      if (text.includes(term)) {
        row.style.display = '';
      } else {
        row.style.display = 'none';
      }
    });
  }, [search]);

  const handleCopy = (e) => {
    const table = tableRef.current;
    if (!table) return;
    const text = table.innerText;
    navigator.clipboard.writeText(text);
    notify.success('Table copied to clipboard');
  };

  const handleExport = (e) => {
    const table = tableRef.current;
    if (!table) return;
    const rows = Array.from(table.querySelectorAll('tr')).map(tr => 
      Array.from(tr.querySelectorAll('th, td')).map(td => td.innerText)
    );
    exportToCsv('ai_report_data', rows);
    notify.success('Report exported to CSV (Excel compatible)');
  };

  return (
    <div className="table-container my-8 group relative animate-slide-up">
      <div className="flex items-center justify-between mb-3 px-1">
        <div className="relative w-full max-w-xs group/search">
          <RiSearchLine className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within/search:text-brand-500 transition-colors" />
          <input 
            type="text" 
            placeholder="Filter table data..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 rounded-xl text-xs focus:ring-4 focus:ring-brand-500/10 focus:border-brand-500 outline-none transition-all dark:text-white"
          />
        </div>

        <div className="flex gap-2">
            <button 
                onClick={handleCopy}
                className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl text-slate-500 dark:text-slate-400 transition-all hover:text-brand-600"
                title="Copy Text"
            >
                <RiFileCopyLine size={18} />
            </button>
            <button 
                onClick={handleExport}
                className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl text-slate-500 dark:text-slate-400 transition-all hover:text-brand-600"
                title="Export to Excel (CSV)"
            >
                <RiDownload2Line size={18} />
            </button>
        </div>
      </div>

      <div className="overflow-x-auto rounded-[2rem] border border-slate-200 dark:border-slate-800 shadow-xl shadow-slate-200/20 dark:shadow-none bg-white dark:bg-slate-900/50 backdrop-blur-sm">
        <table ref={tableRef} className="w-full text-sm text-left border-collapse" {...props}>
          {children}
        </table>
      </div>
    </div>
  );
};

export const AIChart = ({ type, data, title, config = {} }) => {
  if (!data || !data.length) return null;

  const renderChart = () => {
    switch (type?.toLowerCase()) {
      case 'bar':
        return (
          <BarChart data={data}>
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#88888822" />
            <XAxis dataKey={config.xAxis || "name"} axisLine={false} tickLine={false} tick={{ fill: '#888', fontSize: 10 }} />
            <YAxis axisLine={false} tickLine={false} tick={{ fill: '#888', fontSize: 10 }} />
            <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '12px', color: '#fff' }} />
            <Bar dataKey={config.dataKey || "value"} radius={[4, 4, 0, 0]}>
              {data.map((_, i) => <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />)}
            </Bar>
          </BarChart>
        );
      case 'pie':
        return (
          <PieChart>
            <Pie
              data={data}
              cx="50%" cy="50%"
              innerRadius={60} outerRadius={80}
              paddingAngle={5}
              dataKey={config.dataKey || "value"}
            >
              {data.map((_, i) => <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />)}
            </Pie>
            <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '12px', color: '#fff' }} />
          </PieChart>
        );
      case 'area':
      case 'line':
      default:
        const ChartComp = type === 'line' ? LineChart : AreaChart;
        const DataComp = type === 'line' ? Line : Area;
        return (
          <ChartComp data={data}>
             <defs>
                <linearGradient id="colorVal" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor={CHART_COLORS[0]} stopOpacity={0.3} />
                  <stop offset="95%" stopColor={CHART_COLORS[0]} stopOpacity={0} />
                </linearGradient>
              </defs>
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#88888822" />
            <XAxis dataKey={config.xAxis || "name"} axisLine={false} tickLine={false} tick={{ fill: '#888', fontSize: 10 }} />
            <YAxis axisLine={false} tickLine={false} tick={{ fill: '#888', fontSize: 10 }} />
            <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '12px', color: '#fff' }} />
            <DataComp 
                type="monotone" 
                dataKey={config.dataKey || "value"} 
                stroke={CHART_COLORS[0]} 
                strokeWidth={3} 
                fillOpacity={1} 
                fill="url(#colorVal)" 
            />
          </ChartComp>
        );
    }
  };

  return (
    <div className="glass p-6 rounded-3xl border border-slate-200 dark:border-slate-800 my-6 bg-white dark:bg-slate-900/40 shadow-xl shadow-slate-200/20 dark:shadow-none">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-sm font-bold text-slate-800 dark:text-white flex items-center gap-2">
          {type === 'bar' && <RiBarChartLine className="text-indigo-500" />}
          {type === 'pie' && <RiPieChartLine className="text-teal-500" />}
          {(type === 'area' || type === 'line') && <RiLineChartLine className="text-rose-500" />}
          {title || "Data Visualization"}
        </h3>
      </div>
      <div className="h-64 w-full">
        <ResponsiveContainer width="100%" height="100%">
          {renderChart()}
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export const AIRichResponse = ({ content, isStreaming = false }) => {
  // 1. Check for chart data in JSON blocks
  const chartData = useMemo(() => {
    if (!content) return null;
    const chartRegex = /```json\s*\n\s*{\s*"type":\s*"chart"[\s\S]*?}\n\s*```/g;
    const match = content.match(chartRegex);
    if (match) {
        try {
            const jsonText = match[0].replace(/```json/g, '').replace(/```/g, '');
            return JSON.parse(jsonText);
        } catch (e) {
            return null;
        }
    }
    return null;
  }, [content]);

  // 2. Clean content for display (Simple Filter)
  const displayContent = useMemo(() => {
    if (!content) return '';
    let cleaned = content;
    
    // Remove ANY ```json blocks (handled by AIChart)
    cleaned = cleaned.replace(/```json[\s\S]*?(?:```|$)/g, '');
    
    // Remove Suggested Query markers
    cleaned = cleaned.replace(/\[\[SUGGESTED_QUERY:\s*".*?"\]\]/g, '');
    
    return cleaned.trim();
  }, [content]);

  return (
    <div className="prose prose-slate dark:prose-invert prose-brand max-w-none">
      <ReactMarkdown
        remarkPlugins={[remarkGfm]}
        components={{
          table: MarkdownTable,
          thead: ({ node, ...props }) => <thead className="bg-slate-50 dark:bg-slate-800/50" {...props} />,
          th: ({ node, ...props }) => <th className="px-4 py-3 text-xs font-bold text-slate-500 uppercase tracking-wider border-b border-slate-200 dark:border-slate-700" {...props} />,
          td: ({ node, ...props }) => <td className="px-4 py-3 text-sm border-b border-slate-100 dark:border-slate-800/50" {...props} />,
          code: ({ node, inline, ...props }) => (
            inline
              ? <code className="bg-slate-100 dark:bg-slate-800 px-1.5 py-0.5 rounded text-brand-600 dark:text-brand-400 font-bold" {...props} />
              : <div className="relative group">
                  <pre className="bg-slate-900 text-slate-100 p-4 rounded-2xl my-4 overflow-x-auto border border-slate-800 font-mono text-xs leading-relaxed shadow-2xl">
                    <code {...props} />
                  </pre>
                </div>
          ),
          h1: ({ node, ...props }) => <h1 className="text-xl font-black mb-4 mt-8 text-brand-600 border-b-2 border-brand-100 dark:border-brand-900/30 pb-2" {...props} />,
          h2: ({ node, ...props }) => <h2 className="text-lg font-bold mb-3 mt-6 text-slate-800 dark:text-white" {...props} />,
          h3: ({ node, ...props }) => <h3 className="text-base font-bold mb-2 mt-4 text-slate-700 dark:text-slate-200" {...props} />,
          p: ({ node, ...props }) => <p className="mb-4 last:mb-0 leading-relaxed text-slate-600 dark:text-slate-300" {...props} />,
          ul: ({ node, ...props }) => <ul className="list-disc ml-6 mb-4 space-y-2 text-slate-600 dark:text-slate-300" {...props} />,
          ol: ({ node, ...props }) => <ol className="list-decimal ml-6 mb-4 space-y-2 text-slate-600 dark:text-slate-300" {...props} />,
          li: ({ node, ...props }) => <li className="pl-2" {...props} />,
        }}
      >
        {displayContent}
      </ReactMarkdown>
      
      {chartData && (
        <AIChart 
          type={chartData.chartType} 
          data={chartData.data} 
          title={chartData.title} 
          config={chartData.config}
        />
      )}
    </div>
  );
};

export default AIRichResponse;
