import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import {
  RiRobot2Line,
  RiCloseLine,
  RiSendPlane2Fill,
  RiHistoryLine,
  RiInformationLine,
  RiCheckDoubleLine,
  RiHammerLine,
  RiMagicLine,
} from 'react-icons/ri';
import { useAIStore } from '../../store/aiStore';
import { useAuth } from '../../context/AuthContext';
import { useTheme } from '../../context/ThemeContext';
import AIRichResponse from './AIRichResponse';

const MessageBubble = ({ message, isLast, thinkingTime }) => {
  const isAi = message.role === 'ai';
  const { executeAction, sendMessage } = useAIStore();
  const [isExecuting, setIsExecuting] = React.useState(false);
  const [isDone, setIsDone] = React.useState(false);

  // 1. Extract Suggested Actions (JSON blocks)
  let suggestedAction = null;
  if (isAi && message.content && message.content.includes('"type": "SUGGESTED_ACTION"')) {
    try {
      const parts = message.content.split('Please confirm: ');
      if (parts.length > 1) {
        suggestedAction = JSON.parse(parts[1]);
      }
    } catch (e) {
      console.error("Failed to parse suggested action", e);
    }
  }

  // 2. Extract Dynamic Suggestion Chips [[SUGGESTED_QUERY: "Prompt"]]
  let suggestions = [];
  let cleanContent = message.content || "";
  if (isAi && cleanContent) {
    const suggestionRegex = /\[\[SUGGESTED_QUERY:\s*"(.*?)"\]\]/g;
    let match;
    while ((match = suggestionRegex.exec(message.content)) !== null) {
      suggestions.push(match[1]);
    }
    // Remove the markers from the visible text
    cleanContent = cleanContent.replace(/\[\[SUGGESTED_QUERY:\s*".*?"\]\]/g, '').trim();
  }

  const handleConfirmAction = async () => {
    if (!suggestedAction) return;
    setIsExecuting(true);
    try {
      await executeAction(suggestedAction.action, suggestedAction.rationale, suggestedAction.payload);
      setIsDone(true);
    } catch (e) {
      console.error("Action execution failed", e);
    } finally {
      setIsExecuting(false);
    }
  };

  const handleSuggestionClick = (query) => {
    sendMessage(query);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className={`flex flex-col ${isAi ? 'items-start' : 'items-end'} mb-4`}
    >
      <div
        className={`max-w-[90%] px-4 py-3 rounded-2xl text-sm leading-relaxed ${isAi
            ? 'bg-white dark:bg-slate-700/80 text-slate-800 dark:text-slate-100 rounded-tl-none border border-slate-200/60 dark:border-slate-600/40 shadow-sm'
            : 'bg-brand-600 text-white rounded-tr-none shadow-md shadow-brand-500/20'
          }`}
      >
        {isAi && isLast && !message.content ? (
          <div className="flex items-center gap-2 py-1">
            <div className="flex gap-1">
              <span className="w-1.5 h-1.5 bg-brand-500 rounded-full animate-bounce [animation-delay:-0.3s]"></span>
              <span className="w-1.5 h-1.5 bg-brand-500 rounded-full animate-bounce [animation-delay:-0.15s]"></span>
              <span className="w-1.5 h-1.5 bg-brand-500 rounded-full animate-bounce"></span>
            </div>
            {thinkingTime > 0 && (
              <span className="text-[10px] font-bold text-slate-400 dark:text-slate-500 tracking-wider animate-pulse ml-1">
                Thinking {thinkingTime.toFixed(1)}s
              </span>
            )}
          </div>
        ) : (
          <div className={`${isAi ? 'w-full' : ''}`}>
            {isAi ? (
              <AIRichResponse 
                content={suggestedAction ? cleanContent.split('Please confirm: ')[0] : cleanContent} 
                isStreaming={isLast && !message.totalTime}
              />
            ) : (
              <div className="whitespace-pre-wrap">{message.content}</div>
            )}

            {suggestedAction && (
              <div className="mt-4 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-brand-500/30">
                <div className="flex items-center gap-2 text-brand-600 dark:text-brand-400 font-bold text-xs mb-2">
                  <RiHammerLine size={14} />
                  PROPOSED ACTION
                </div>
                <div className="text-xs font-bold text-slate-700 dark:text-slate-200 mb-1">
                  {suggestedAction.action}: {suggestedAction.target}
                </div>
                <p className="text-[10px] opacity-70 mb-3 italic">
                  Rationale: {suggestedAction.rationale}
                </p>
                <button
                  onClick={handleConfirmAction}
                  disabled={isExecuting || isDone}
                  className={`w-full py-2 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-2 ${isDone
                      ? 'bg-accent-500 text-white cursor-default'
                      : 'bg-brand-600 hover:bg-brand-700 text-white shadow-lg shadow-brand-500/30'
                    }`}
                >
                  {isExecuting ? 'Executing...' : isDone ? <><RiCheckDoubleLine /> Done</> : 'Confirm Action'}
                </button>
              </div>
            )}
          </div>
        )}
      </div>
      
      {/* Dynamic Suggestion Chips */}
      {isAi && isLast && suggestions.length > 0 && (
        <div className="flex flex-wrap gap-2 mt-2 px-1">
          {suggestions.map((s, i) => (
            <motion.button
              key={i}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.1 }}
              onClick={() => handleSuggestionClick(s)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 
                         border border-indigo-200/50 dark:border-indigo-700/50 text-[10px] font-bold hover:bg-indigo-100 transition-all shadow-sm"
            >
              <RiMagicLine size={12} />
              {s}
            </motion.button>
          ))}
        </div>
      )}

      {/* Removed redundant Answered In label in favor of the Thought bar */}
    </motion.div>
  );
};

const AICopilot = () => {
  const { user } = useAuth();
  const { isDark } = useTheme();
  const {
    messages,
    isChatOpen,
    isLoading,
    isHistoryLoading,
    thinkingTime,
    toggleChat,
    sendMessage,
    conversations,
    currentConversationId,
    loadConversations,
    loadConversation,
    startNewChat,
    deleteConversation
  } = useAIStore();

  const [inputValue, setInputValue] = useState('');
  const [showHistory, setShowHistory] = useState(false);
  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    if (isChatOpen) {
      loadConversations();
    }
  }, [isChatOpen]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!inputValue.trim() || isLoading) return;
    sendMessage(inputValue);
    setInputValue('');
  };

  const handleSelectConversation = (id) => {
    loadConversation(id);
    setShowHistory(false);
  };

  const handleNewChat = () => {
    startNewChat();
    setShowHistory(false);
  };

  return (
    <div className="fixed bottom-6 right-6 z-[9999]">
      {/* Floating Action Button */}
      <motion.button
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={toggleChat}
        className={`flex items-center justify-center w-14 h-14 rounded-full shadow-xl transition-all duration-300 ${isChatOpen
            ? 'bg-slate-800 dark:bg-slate-600 text-white'
            : 'bg-gradient-to-br from-brand-600 to-accent-500 text-white hover:shadow-brand-500/40 hover:shadow-2xl'
          }`}
      >
        {isChatOpen ? <RiCloseLine size={24} /> : <RiRobot2Line size={28} className="animate-pulse-slow" />}
      </motion.button>

      {/* Chat Window */}
      <AnimatePresence>
        {isChatOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            transition={{ type: 'spring', damping: 25, stiffness: 300 }}
            className="absolute bottom-16 right-0 w-96 h-[500px] rounded-2xl shadow-2xl flex flex-col overflow-hidden
                       bg-slate-50/90 dark:bg-slate-800/60 backdrop-blur-md 
                       border border-slate-200/60 dark:border-slate-700/50"
          >
            {/* Header */}
            <div className="bg-gradient-to-r from-brand-600 to-accent-500 p-4 text-white flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="bg-white/20 p-2 rounded-xl backdrop-blur-md">
                  <RiRobot2Line size={20} />
                </div>
                <div>
                  <h3 className="font-bold text-sm tracking-wide">DevOps Copilot</h3>
                  <p className="text-[10px] opacity-80 uppercase font-bold tracking-widest">AI Powered</p>
                </div>
              </div>
              <div className="flex gap-3 items-center">
                <button 
                  onClick={handleNewChat}
                  className="bg-white/10 hover:bg-white/20 px-2 py-1 rounded-lg text-[10px] font-bold border border-white/20 transition-all"
                >
                  + NEW CHAT
                </button>
                <RiHistoryLine 
                  className={`cursor-pointer hover:opacity-70 transition-opacity ${showHistory ? 'text-white' : 'text-white/60'}`} 
                  title="History"
                  onClick={() => setShowHistory(!showHistory)} 
                />
              </div>
            </div>

            {/* History Sidebar Overlay */}
            <AnimatePresence>
              {showHistory && (
                <motion.div
                  initial={{ x: -384 }}
                  animate={{ x: 0 }}
                  exit={{ x: -384 }}
                  transition={{ type: 'spring', damping: 20, stiffness: 200 }}
                  className="absolute inset-x-0 bottom-0 top-[64px] z-50 bg-slate-50 dark:bg-slate-800 border-r border-slate-200 dark:border-slate-700 flex flex-col"
                >
                  <div className="p-4 border-b border-slate-200 dark:border-slate-700 flex justify-between items-center bg-slate-100/50 dark:bg-slate-900/50">
                    <span className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-widest">Chat History</span>
                    <button onClick={handleNewChat} className="text-brand-600 dark:text-brand-400 text-[10px] font-bold hover:underline">+ NEW</button>
                  </div>
                  <div className="flex-1 overflow-y-auto p-2">
                    {isHistoryLoading ? (
                      <div className="p-8 text-center flex flex-col items-center gap-2">
                        <RiHistoryLine size={24} className="animate-spin text-brand-500 opacity-50" />
                        <span className="text-[10px] text-slate-400 font-bold tracking-widest uppercase">Syncing Cloud History...</span>
                      </div>
                    ) : conversations.length === 0 ? (
                      <div className="p-8 text-center text-[10px] text-slate-400 italic">No previous sessions found</div>
                    ) : (
                      conversations.map(conv => (
                        <div 
                          key={conv.id}
                          className={`group relative p-3 mb-1 rounded-xl cursor-pointer transition-all ${currentConversationId === conv.id 
                            ? 'bg-brand-500/10 border border-brand-500/30' 
                            : 'hover:bg-slate-200/50 dark:hover:bg-slate-700/50'
                          }`}
                          onClick={() => handleSelectConversation(conv.id)}
                        >
                          <div className="text-xs font-bold text-slate-700 dark:text-slate-200 truncate pr-6">
                            {conv.title}
                          </div>
                          <div className="text-[10px] text-slate-400 mt-1">
                            {new Date(conv.created_at).toLocaleDateString()}
                          </div>
                          <button 
                            onClick={(e) => { e.stopPropagation(); deleteConversation(conv.id); }}
                            className="absolute right-3 top-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 text-slate-400 hover:text-red-500 transition-all"
                          >
                            <RiCloseLine size={16} />
                          </button>
                        </div>
                      ))
                    )}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Messages Area */}
            <div className="flex-1 overflow-y-auto p-4 bg-slate-100/60 dark:bg-slate-900/30">
              {messages.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-center p-6 text-slate-400 dark:text-slate-500">
                  <RiRobot2Line size={48} className="mb-4 opacity-20" />
                  <p className="text-sm font-semibold text-slate-500 dark:text-slate-400">Hello, {user?.first_name}!</p>
                  <p className="text-xs mt-1">Start a diagnostic thread or browse your history.</p>
                </div>
              ) : (
                messages.map((msg, idx) => (
                  <MessageBubble
                    key={idx}
                    message={msg}
                    isLast={idx === messages.length - 1}
                    thinkingTime={thinkingTime}
                  />
                ))
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Input Area */}
            <form onSubmit={handleSubmit} className="p-3 flex gap-2 bg-slate-50 dark:bg-slate-800 border-t border-slate-200/60 dark:border-slate-700">
              <input
                type="text"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                placeholder="Ask something..."
                className="form-input !rounded-xl !py-2.5 flex-1"
                disabled={isLoading}
              />
              <button
                type="submit"
                disabled={isLoading || !inputValue.trim()}
                className={`p-2.5 rounded-xl transition-all duration-200 ${isLoading || !inputValue.trim()
                    ? 'bg-slate-100 dark:bg-slate-700 text-slate-300 dark:text-slate-500 cursor-not-allowed'
                    : 'btn-primary !p-2.5'
                  }`}
              >
                <RiSendPlane2Fill size={18} />
              </button>
            </form>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default AICopilot;
