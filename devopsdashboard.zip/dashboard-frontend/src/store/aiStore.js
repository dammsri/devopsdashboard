import { create } from 'zustand';
import axios from 'axios';

const api = axios.create({
  baseURL: 'http://localhost:8000/api/v1',
  withCredentials: true,
});

// Add a request interceptor to attach the token
api.interceptors.request.use((config) => {
  const token = window.__ACCESS_TOKEN__ || localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
}, (error) => {
  return Promise.reject(error);
});

export const useAIStore = create((set, get) => ({
  messages: [],
  isChatOpen: false,
  isLoading: false,
  isHistoryLoading: false,
  thinkingTime: 0,
  insights: [],
  conversations: [],
  currentConversationId: null,
  
  toggleChat: () => set((state) => ({ isChatOpen: !state.isChatOpen })),
  
  loadConversations: async () => {
    try {
      set({ isHistoryLoading: true });
      const response = await api.get('/ai/conversations');
      set({ conversations: response.data, isHistoryLoading: false });
    } catch (error) {
      console.error('Failed to load conversations:', error);
      set({ isHistoryLoading: false });
    }
  },

  loadConversation: async (id) => {
    try {
      set({ isLoading: true });
      const response = await api.get(`/ai/conversations/${id}`);
      set({ 
        currentConversationId: id,
        messages: response.data.messages,
        isLoading: false 
      });
    } catch (error) {
      console.error('Failed to load conversation details:', error);
      set({ isLoading: false });
    }
  },

  startNewChat: () => {
    set({ 
      messages: [], 
      currentConversationId: null,
      isChatOpen: true 
    });
  },

  deleteConversation: async (id) => {
    try {
      await api.delete(`/ai/conversations/${id}`);
      const { conversations, currentConversationId } = get();
      set({ 
        conversations: conversations.filter(c => c.id !== id),
        currentConversationId: currentConversationId === id ? null : currentConversationId,
        messages: currentConversationId === id ? [] : get().messages
      });
    } catch (error) {
      console.error('Failed to delete conversation:', error);
    }
  },

  addMessage: (message) => set((state) => ({ 
    messages: [...state.messages, message] 
  })),
  
  fetchInsights: async () => {
    try {
      const response = await api.get('/ai/insights');
      set({ insights: response.data.insights });
    } catch (error) {
      console.error('Failed to fetch AI insights:', error);
    }
  },
  
  sendMessage: async (text) => {
    const { messages, currentConversationId } = get();
    const newUserMessage = { role: 'user', content: text };
    
    set((state) => ({ 
      messages: [...state.messages, newUserMessage],
      isLoading: true,
      thinkingTime: 0
    }));
    
    let timerInterval = setInterval(() => {
      set((state) => ({ thinkingTime: state.thinkingTime + 0.1 }));
    }, 100);
    
    try {
      const response = await fetch('http://localhost:8000/api/v1/ai/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${window.__ACCESS_TOKEN__}`
        },
        body: JSON.stringify({
          message: text,
          conversation_id: currentConversationId,
          history: messages.slice(-10) // Send recent context
        })
      });
      
      if (!response.ok) {
        if (timerInterval) clearInterval(timerInterval);
        const errorData = await response.json().catch(() => ({}));
        set((state) => ({
          messages: [...state.messages, { 
            role: 'assistant', 
            content: `**Error:** Failed to connect to AI Service (${response.status}). ${JSON.stringify(errorData.detail || '')}` 
          }],
          isLoading: false,
          thinkingTime: 0
        }));
        return;
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let aiResponseContent = '';
      let firstChunkReceived = false;
      
      const aiMessagePlaceholder = { role: 'assistant', content: '', totalTime: 0 };
      set((state) => ({ messages: [...state.messages, aiMessagePlaceholder] }));
      
      while (true) {
        const { value, done } = await reader.read();
        if (done) {
          if (timerInterval) clearInterval(timerInterval);
          // Refresh conversation list to show updated title or time
          get().loadConversations();
          break;
        }
        
        const chunk = decoder.decode(value);
        const lines = chunk.split('\n');
        
        for (const line of lines) {
          if (line.startsWith('data: ')) {
            try {
              const data = JSON.parse(line.slice(6));
              
              // NEW: Handle conversation metadata if it's the first chunk of a new chat
              if (data.conversation_id && !get().currentConversationId) {
                set({ currentConversationId: data.conversation_id });
              }

              if (data.error) {
                if (timerInterval) clearInterval(timerInterval);
                set((state) => {
                  const newMessages = [...state.messages];
                  if (newMessages.length > 0) {
                    newMessages[newMessages.length - 1].content = `**Error:** ${data.error}`;
                  }
                  return { messages: newMessages, isLoading: false, thinkingTime: 0 };
                });
                return;
              }

              if (data.content !== undefined && data.content !== null) {
                aiResponseContent += data.content;
                let finalThinkingTime = 0;
                let stopTimer = false;

                if (!firstChunkReceived) {
                  firstChunkReceived = true;
                  if (timerInterval) {
                    clearInterval(timerInterval);
                    timerInterval = null;
                    finalThinkingTime = get().thinkingTime;
                    stopTimer = true;
                  }
                }

                set((state) => {
                  const newMessages = [...state.messages];
                  if (newMessages.length > 0) {
                    const lastIdx = newMessages.length - 1;
                    newMessages[lastIdx] = { 
                      ...newMessages[lastIdx], 
                      content: aiResponseContent,
                      totalTime: stopTimer ? finalThinkingTime : newMessages[lastIdx].totalTime
                    };
                  }
                  return { 
                    messages: newMessages, 
                    thinkingTime: stopTimer ? 0 : state.thinkingTime 
                  };
                });
              }
            } catch (e) {
              console.error('Error parsing SSE chunk:', e);
            }
          }
        }
      }
    } catch (error) {
      if (timerInterval) clearInterval(timerInterval);
      set((state) => ({ 
        messages: [...state.messages, { role: 'assistant', content: 'Sorry, I encountered an error. Please check the backend connection.' }]
      }));
    }
 finally {
      if (timerInterval) clearInterval(timerInterval);
      set({ isLoading: false, thinkingTime: 0 });
    }
  },
  
  executeAction: async (action, rationale, payload) => {
    try {
      const response = await api.post('/ai/execute', { action, rationale, payload });
      return response.data;
    } catch (error) {
      console.error('Failed to execute AI action:', error);
      throw error;
    }
  },

  clearStore: () => {
    set({
      messages: [],
      conversations: [],
      currentConversationId: null,
      insights: [],
      isLoading: false,
      isChatOpen: false,
      thinkingTime: 0,
      isHistoryLoading: false
    });
  }
}));
