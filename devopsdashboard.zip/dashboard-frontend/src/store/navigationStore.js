import { create } from 'zustand';
import { applicationsApi, infrastructureApi, k8sEnvironmentsApi } from '../api/services';

const useNavigationStore = create((set, get) => ({
    applications: [],
    infrastructure: [],
    k8sEnvironments: [],
    loading: false,
    error: null,

    refreshAll: async () => {
        set({ loading: true, error: null });
        try {
            const [appsRes, infraRes, k8sRes] = await Promise.all([
                applicationsApi.getApplications(),
                infrastructureApi.getInfrastructureGroups(),
                k8sEnvironmentsApi.getEnvironments()
            ]);
            
            set({
                applications: appsRes.data || [],
                infrastructure: infraRes.data || [],
                k8sEnvironments: k8sRes.data || [],
                loading: false
            });
        } catch (err) {
            console.error("Navigation store failed to refresh", err);
            set({ error: err.message, loading: false });
        }
    }
}));

export default useNavigationStore;
