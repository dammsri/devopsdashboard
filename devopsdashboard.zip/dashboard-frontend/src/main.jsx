import React, { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { ThemeProvider } from './context/ThemeContext'; 
import { PreferencesProvider } from './context/PreferencesContext';
import { ProtectedRoute, RoleGuard } from './routes/guards';
import AppShell from './components/layout/AppShell';
import LoginPage from './pages/LoginPage';
import DashboardHome from './pages/DashboardHome';
import ApplicationSummary from './pages/ApplicationSummary';
import ApplicationDetail from './pages/ApplicationDetail';
import EnvironmentSummary from './pages/EnvironmentSummary';
import InfrastructureCategoryDetail from './pages/InfrastructureCategoryDetail';
import InfrastructureServerList from './pages/InfrastructureServerList';
import K8sEnvironmentServiceGrid from './pages/K8sEnvironmentServiceGrid';
import K8sServiceDetail from './pages/K8sServiceDetail';
import SettingsDashboard from './pages/SettingsDashboard';
import ErrorBoundary from './components/common/ErrorBoundary';
import logger from './utils/logger';
import './index.css';

// ── Startup Log ─────────────────────────────────────────────────────────────
logger.info('🚀 DevOps Dashboard Frontend Starting...', {
    version: '1.2.0',
    env: import.meta.env.MODE,
    screen: `${window.innerWidth}x${window.innerHeight}`
});

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <ErrorBoundary>
      <BrowserRouter>
      <ThemeProvider>
        <PreferencesProvider>
          <AuthProvider>
            <Routes>
              <Route path="/login" element={<LoginPage />} />
            
            <Route path="/" element={<Navigate to="/dashboard" replace />} />
            
            <Route path="/dashboard" element={<ProtectedRoute><AppShell /></ProtectedRoute>}>
              <Route index element={<DashboardHome />} />
              
              {/* Summary Dashboard (Aggregated View) */}
              <Route path="summary/:itamId" element={<ApplicationSummary />} />

              {/* Drill-down Targets (Kept for AI exploration) */}
              <Route path="applications/:appId" element={<ApplicationDetail />} />
              <Route path="applications/:appId/environments/:envId" element={<EnvironmentSummary />} />
              
              <Route path="infrastructure/:category" element={<InfrastructureCategoryDetail />} />
              <Route path="infrastructure/:category/:appId" element={<InfrastructureServerList />} />
              
              <Route path="k8s-environments/:k8sEnvId" element={<K8sEnvironmentServiceGrid />} />
              <Route path="k8s-environments/:k8sEnvId/services/:serviceId" element={<K8sServiceDetail />} />

              {/* Settings */}
              <Route path="settings" element={<SettingsDashboard />} />
              <Route path="settings/:category" element={<SettingsDashboard />} />

            </Route>

            <Route path="*" element={<Navigate to="/dashboard" replace />} />
          </Routes>
        </AuthProvider>
        </PreferencesProvider>
      </ThemeProvider>
      </BrowserRouter>
    </ErrorBoundary>
  </StrictMode>
);
