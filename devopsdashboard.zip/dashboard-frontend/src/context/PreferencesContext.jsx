import { createContext, useContext, useState, useEffect } from "react";

const PreferencesContext = createContext();

export function PreferencesProvider({ children }) {
  const [darkMode, setDarkMode] = useState(() => {
    return localStorage.getItem("devops_copilot_theme") === "dark";
  });

  const [fontScale, setFontScale] = useState(() => {
    return parseInt(localStorage.getItem("devops_copilot_font_scale")) || 100;
  });

  useEffect(() => {
    localStorage.setItem("devops_copilot_theme", darkMode ? "dark" : "light");
    if (darkMode) {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
  }, [darkMode]);

  useEffect(() => {
    localStorage.setItem("devops_copilot_font_scale", fontScale);
    document.documentElement.style.fontSize = `${fontScale}%`;
  }, [fontScale]);

  return (
    <PreferencesContext.Provider value={{ darkMode, setDarkMode, fontScale, setFontScale }}>
      {children}
    </PreferencesContext.Provider>
  );
}

export function usePreferences() {
  return useContext(PreferencesContext);
}
