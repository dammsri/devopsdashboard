/** @type {import('tailwindcss').Config} */
import forms from "@tailwindcss/forms";

export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  darkMode: "class",
  theme: {
    extend: {
      fontFamily: {
        sans: ["var(--font-family-sans)", "Inter", "system-ui", "sans-serif"],
        display: ["var(--font-family-display)", "Outfit", "system-ui", "sans-serif"],
      },
      colors: {
        brand: {
          50:  "#eef7ff",
          100: "#cde3fb",
          200: "#badfff",
          300: "#8accff",
          400: "#54adff",
          500: "#337be5", 
          600: "#0473ea", 
          700: "#005bc1",
          800: "#004d9c",
          900: "#004085",
        },
        accent: {
          50:  "#ebfae5",
          100: "#cdf4bf",
          200: "#d7f6cc",
          300: "#9be880",
          400: "#92e773",
          500: "#38d200", 
          600: "#238500", 
          700: "#1b6600", 
          800: "#0b2900", 
          900: "#061700",
        },
        primaryDeep: {
          900: "#020b43",
        }
      },
      animation: {
        "fade-in":    "fadeIn 0.4s ease-out",
        "slide-in":   "slideIn 0.3s ease-out",
        "pulse-slow": "pulse 3s cubic-bezier(0.4,0,0.6,1) infinite",
      },
      keyframes: {
        fadeIn:  { "0%": { opacity: 0, transform: "translateY(8px)" }, "100%": { opacity: 1, transform: "translateY(0)" } },
        slideIn: { "0%": { opacity: 0, transform: "translateX(-12px)" }, "100%": { opacity: 1, transform: "translateX(0)" } },
      },
    },
  },
  plugins: [forms],
};
