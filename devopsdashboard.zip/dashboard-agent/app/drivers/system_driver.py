import os
import psutil
import subprocess
import logging
from typing import Dict, Any, Optional
from .base import BaseDriver

logger = logging.getLogger(__name__)

class SystemDriver(BaseDriver):
    """
    Driver for executing system-level commands and retrieving host metrics.
    Turns the Dashboard Agent into a general-purpose Infra Agent.
    """
    
    def get_status(self) -> Dict[str, Any]:
        return {
            "status": "up", 
            "driver": "system",
            "os": os.name,
            "platform": psutil.sys.platform
        }

    def get_metrics(self) -> Dict[str, Any]:
        cpu_percent = psutil.cpu_percent(interval=None)
        memory = psutil.virtual_memory()
        disk = psutil.disk_usage('/')
        
        return {
            "host": {
                "cpu_usage": f"{cpu_percent}%",
                "mem_usage": f"{memory.used // (1024*1024)}MB / {memory.total // (1024*1024)}MB",
                "disk_usage": f"{disk.percent}%",
                "uptime": self._get_uptime()
            },
            "system_info": {
                "cpu_count": psutil.cpu_count(),
                "boot_time": psutil.boot_time()
            }
        }

    def execute_instruction(self, action: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        params = params or {}
        
        if action == "execute_command":
            command = params.get("command")
            if not command:
                return {"status": "error", "message": "No command provided"}
            
            logger.info(f"🚀 [SYSTEM] Executing shell command: {command}")
            try:
                # Run command with 30s timeout
                result = subprocess.run(
                    command, 
                    shell=True, 
                    capture_output=True, 
                    text=True, 
                    timeout=30
                )
                
                return {
                    "status": "success",
                    "stdout": result.stdout,
                    "stderr": result.stderr,
                    "exit_code": result.returncode
                }
            except subprocess.TimeoutExpired:
                return {"status": "error", "message": "Command timed out after 30 seconds"}
            except Exception as e:
                return {"status": "error", "message": f"Execution failed: {str(e)}"}
        
        elif action == "get_process_list":
            processes = []
            for proc in psutil.process_iter(['pid', 'name', 'username', 'cpu_percent', 'memory_info']):
                try:
                    pinfo = proc.info
                    pinfo['memory_mb'] = pinfo['memory_info'].rss // (1024 * 1024)
                    processes.append(pinfo)
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    pass
            # Sort by CPU usage and return top 20
            sorted_procs = sorted(processes, key=lambda x: x.get('cpu_percent', 0), reverse=True)
            return {"status": "success", "data": sorted_procs[:20]}

        elif action == "manage_service":
            service = params.get("service")
            op = params.get("operation") # start, stop, restart, status
            if not service or not op:
                return {"status": "error", "message": "Missing service name or operation"}
            
            cmd = f"systemctl {op} {service}"
            logger.info(f"⚙️ [SYSTEM] Managing service: {cmd}")
            try:
                result = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=10)
                return {
                    "status": "success" if result.returncode == 0 else "error",
                    "stdout": result.stdout,
                    "stderr": result.stderr,
                    "exit_code": result.returncode
                }
            except Exception as e:
                return {"status": "error", "message": f"Service management failed: {str(e)}"}

        elif action == "read_file":
            path = params.get("path")
            lines = int(params.get("lines", 100))
            if not path or not os.path.exists(path):
                return {"status": "error", "message": f"File not found: {path}"}
            
            try:
                with open(path, 'r') as f:
                    content = [next(f) for _ in range(lines)]
                return {"status": "success", "content": "".join(content), "path": path}
            except StopIteration:
                return {"status": "success", "content": "".join(content), "path": path} # reached EOF
            except Exception as e:
                return {"status": "error", "message": f"Failed to read file: {str(e)}"}

        elif action == "get_network_info":
            try:
                connections = []
                for conn in psutil.net_connections(kind='inet'):
                    connections.append({
                        "fd": conn.fd,
                        "family": str(conn.family),
                        "type": str(conn.type),
                        "laddr": f"{conn.laddr.ip}:{conn.laddr.port}",
                        "raddr": f"{conn.raddr.ip}:{conn.raddr.port}" if conn.raddr else None,
                        "status": conn.status,
                        "pid": conn.pid
                    })
                return {"status": "success", "connections": connections[:50]}
            except Exception as e:
                return {"status": "error", "message": f"Failed to get network info: {str(e)}"}

        return {"status": "error", "message": f"Unsupported System action: {action}"}

    def _get_uptime(self) -> str:
        try:
            with open('/proc/uptime', 'r') as f:
                uptime_seconds = float(f.readline().split()[0])
                days = int(uptime_seconds // (24 * 3600))
                hours = int((uptime_seconds % (24 * 3600)) // 3600)
                return f"{days}d {hours}h"
        except:
            return "Unknown"
