import os
import psutil
import logging
from typing import Dict, Any, Optional, List
from .base import BaseDriver

try:
    import podman
    from podman.errors import PodmanError
except ImportError:
    podman = None

logger = logging.getLogger(__name__)

class PodmanDriver(BaseDriver):
    def __init__(self):
        self.client = None
        self.use_mock = True
        
        if podman:
            try:
                # Attempt to connect to the Podman service
                # Default locations: 
                # - Rootful: unix:///run/podman/podman.sock
                # - Rootless: unix:///run/user/$UID/podman/podman.sock
                # PodmanClient() with no args tries to resolve from environment
                self.client = podman.PodmanClient()
                self.client.ping()
                self.use_mock = False
                logger.info("📦 Podman Driver connected to real Podman service.")
            except Exception as e:
                logger.warning(f"⚠️ Podman service unreachable: {e}. Falling back to mock data.")
        else:
            logger.warning("⚠️ podman library not installed. Using mock data.")

    def get_status(self) -> Dict[str, Any]:
        return {
            "status": "up", 
            "driver": "podman",
            "real_service": not self.use_mock
        }

    def get_metrics(self) -> Dict[str, Any]:
        # 1. Host Metrics (Always real)
        cpu_percent = psutil.cpu_percent(interval=None)
        memory = psutil.virtual_memory()
        
        # 2. Container Metrics
        containers = []
        if self.use_mock:
            containers = self._get_mock_containers()
        else:
            try:
                for c in self.client.containers.list(all=True):
                    # Basic container info
                    c_data = {
                        "name": c.name,
                        "image": c.image.tags[0] if c.image.tags else c.image.id[:12],
                        "status": c.status,
                        "health": c.attrs.get("State", {}).get("Health", {}).get("Status", "unknown"),
                        "id": c.id[:12]
                    }
                    
                    # Try to get stats (non-streaming)
                    try:
                        stats = c.stats(stream=False)
                        if stats:
                            s = stats[0]
                            c_data["cpu_usage"] = f"{s.get('CPUPercentage', 0):.1f}%"
                            c_data["mem_usage"] = f"{s.get('MemUsage', 0) // (1024*1024)}MB"
                    except:
                        c_data["cpu_usage"] = "N/A"
                        c_data["mem_usage"] = "N/A"
                        
                    containers.append(c_data)
            except Exception as e:
                logger.error(f"Error fetching real Podman containers: {e}")
                containers = self._get_mock_containers()
        
        return {
            "host": {
                "cpu_usage": f"{cpu_percent}%",
                "mem_usage": f"{memory.used // (1024*1024)}MB / {memory.total // (1024*1024)}MB",
                "uptime": self._get_uptime(),
                "patch_level": "Optimized"
            },
            "containers": containers
        }

    def execute_instruction(self, action: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        service_name = params.get("service_name") if params else "unknown"
        logger.info(f"⚡ [PODMAN] Executing {action} for {service_name}")

        if self.use_mock:
            return self._execute_mock_instruction(action, service_name)

        try:
            container = self.client.containers.get(service_name)
            
            if action == "get_logs":
                logs = container.logs(tail=100).decode("utf-8")
                return {"status": "success", "data": logs}
                
            elif action == "get_configuration":
                return {"status": "success", "data": container.attrs}
                
            elif action == "restart":
                container.restart()
                return {"status": "success", "message": f"Successfully restarted container: {service_name}"}
                
            elif action == "get_status":
                return {"status": "success", "data": {"state": container.status, "health": container.attrs.get("State", {}).get("Health", {})}}

        except Exception as e:
            logger.error(f"Podman action {action} failed for {service_name}: {e}")
            return {"status": "error", "message": str(e)}
        
        return {"status": "error", "message": f"Unsupported Podman action: {action}"}

    def _get_mock_containers(self) -> List[Dict[str, Any]]:
        return [
            {"name": "api-gateway", "image": "devops/apigw:v1.2.3", "status": "running", "health": "healthy", "cpu_usage": "2.5%", "mem_usage": "256MB"},
            {"name": "frontend", "image": "devops/frontend:v1.1.0", "status": "running", "health": "healthy", "cpu_usage": "1.2%", "mem_usage": "128MB"}
        ]

    def _execute_mock_instruction(self, action: str, service_name: str) -> Dict[str, Any]:
        if action == "get_logs":
            return {"status": "success", "data": f"MOCK LOGS for {service_name}\n2026-04-22 [INFO] Service operational."}
        elif action == "get_configuration":
            return {"status": "success", "data": {"Mock": True, "Image": "devops/mock:latest"}}
        elif action == "restart":
            return {"status": "success", "message": f"MOCK: Restarted {service_name}"}
        return {"status": "error", "message": f"Unsupported mock action: {action}"}

    def _get_uptime(self) -> str:
        with open('/proc/uptime', 'r') as f:
            uptime_seconds = float(f.readline().split()[0])
            days = int(uptime_seconds // (24 * 3600))
            hours = int((uptime_seconds % (24 * 3600)) // 3600)
            return f"{days}d {hours}h"
