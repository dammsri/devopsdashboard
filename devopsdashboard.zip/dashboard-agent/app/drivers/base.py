from abc import ABC, abstractmethod
from typing import Dict, Any, Optional

class BaseDriver(ABC):
    """
    Abstract base class for all dashboard agent drivers.
    Defines the contract for infrastructure-specific operations.
    """
    
    @abstractmethod
    def get_status(self) -> Dict[str, Any]:
        """Returns the health and operational status of the target."""
        pass

    @abstractmethod
    def get_metrics(self) -> Dict[str, Any]:
        """Returns performance and resource metrics."""
        pass

    @abstractmethod
    def execute_instruction(self, action: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Executes a proactive or remediation instruction."""
        pass
