import os
import time
import uuid
import json
import secrets
import logging
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, Header, Request
from typing import Optional, List, Dict, Any
from pydantic import BaseModel
from enum import Enum
from starlette.middleware.base import BaseHTTPMiddleware

from app.core.logging_config import setup_logging, correlation_id
from app.drivers.k8s_driver import K8sDriver
from app.drivers.podman_driver import PodmanDriver
from app.drivers.system_driver import SystemDriver

# ── Load Environment Configuration ─────────────────────────────────────────
load_dotenv()

# ── Logging & Mode Configuration ───────────────────────────────────────────
os.environ.setdefault("SERVICE_NAME", "dashboard-agent")
logger = setup_logging()

AGENT_MODE = os.getenv("AGENT_MODE", "podman").lower()
# NO DEFAULT for sensitive secret — will fail verify_token if not set
AGENT_SECRET = os.getenv("AGENT_SECRET")

if not AGENT_SECRET:
    logger.error("❌ CRITICAL: AGENT_SECRET environment variable is not set. Service will not accept instructions.")
    # In production, we might want to raise SystemExit here.
    # raise SystemExit("AGENT_SECRET not set")

# ── Driver Selection ─────────────────────────────────────────────────────────
if AGENT_MODE == "k8s":
    driver = K8sDriver()
elif AGENT_MODE == "podman":
    driver = PodmanDriver()
elif AGENT_MODE in ["infra", "system"]:
    driver = SystemDriver()
else:
    raise ValueError(f"Unsupported AGENT_MODE: {AGENT_MODE}")

# ── Middleware ─────────────────────────────────────────────────────────────
class LoggingMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        request_id = request.headers.get("X-Request-ID") or str(uuid.uuid4())
        token = correlation_id.set(request_id)
        start_time = time.time()
        
        response = await call_next(request)
        duration = time.time() - start_time
        
        logger.info(f"{request.method} {request.url.path} - {response.status_code}", extra={
            "method": request.method,
            "path": request.url.path,
            "status_code": response.status_code,
            "duration_ms": round(duration * 1000, 2),
            "mode": AGENT_MODE
        })
        
        correlation_id.reset(token)
        response.headers["X-Request-ID"] = request_id
        return response

app = FastAPI(title=f"DevOps Dashboard Agent ({AGENT_MODE.upper()})")
app.add_middleware(LoggingMiddleware)

def verify_token(x_agent_secret: str = Header(None)):
    """Constant-time secret comparison to prevent timing attacks."""
    if not x_agent_secret or not secrets.compare_digest(x_agent_secret, AGENT_SECRET):
        raise HTTPException(status_code=403, detail="Forbidden")

# ── Endpoints ─────────────────────────────────────────────────────────────
@app.get("/health")
def health():
    return driver.get_status()

@app.get("/metrics")
def get_metrics(x_agent_secret: str = Header(None)):
    verify_token(x_agent_secret)
    return driver.get_metrics()

@app.get("/environment/{k8s_env_id}/services")
def get_k8s_services(k8s_env_id: str, x_agent_secret: str = Header(None)):
    """K8s-specific metrics endpoint compatibility."""
    verify_token(x_agent_secret)
    if AGENT_MODE != "k8s":
        raise HTTPException(status_code=400, detail="Environment services only available in K8S mode")
    return driver.get_metrics()

class AgentAction(str, Enum):
    get_logs = "get_logs"
    get_configuration = "get_configuration"
    get_resource_definitions = "get_resource_definitions"
    restart = "restart"
    get_metrics = "get_metrics"
    get_status = "get_status"
    execute_command = "execute_command"
    get_process_list = "get_process_list"

class InstructionPayload(BaseModel):
    # Unified payload to support both K8S and PODMAN driver signatures
    action: AgentAction
    params: Optional[Dict[str, Any]] = None
    # Support K8S fields
    k8s_env_id: Optional[str] = None
    namespace: Optional[str] = None
    service_id: Optional[str] = None
    # Support Podman fields
    service_name: Optional[str] = None

@app.post("/instruction")
def execute_instruction(payload: InstructionPayload, x_agent_secret: str = Header(None)):
    verify_token(x_agent_secret)
    
    # Merge instruction fields into params for drivers to consume as they wish
    instruction_params = payload.params or {}
    if payload.k8s_env_id: instruction_params["k8s_env_id"] = payload.k8s_env_id
    if payload.namespace: instruction_params["namespace"] = payload.namespace
    if payload.service_id: instruction_params["service_id"] = payload.service_id
    if payload.service_name: instruction_params["service_name"] = payload.service_name
    
    return driver.execute_instruction(payload.action, instruction_params)

if __name__ == "__main__":
    import uvicorn
    # Defaulting to standardized port 8005 per plan
    port = int(os.getenv("AGENT_PORT", 8005))
    uvicorn.run(app, host="0.0.0.0", port=port)
